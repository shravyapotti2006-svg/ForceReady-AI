import mysql.connector


def get_connection():
    connection = mysql.connector.connect(
        host="127.0.0.1",
        port=3306,
        user="root",
        password="12345",
        database="forceready",
        connection_timeout=5,
        use_pure=True
    )

    return connection


# Test MySQL connection
if __name__ == "__main__":
    try:
        print("Connecting to MySQL...")

        connection = get_connection()

        if connection.is_connected():
            print("MySQL Connected Successfully!")
            print("Database: forceready")

        connection.close()
        print("Connection closed.")

    except mysql.connector.Error as error:
        print("MySQL Connection Failed!")
        print("Error:", error)