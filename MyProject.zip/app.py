import json
from datetime import datetime
from flask import Flask, render_template, request, redirect, url_for, session
from database import get_connection
from ai_engine import generate_fitness_recommendations, generate_career_recommendations, generate_diet_recommendations, generate_daily_schedule, generate_readiness_analysis, generate_chatbot_response
from werkzeug.security import generate_password_hash, check_password_hash


# =====================================================
# FLASK APPLICATION
# =====================================================

app = Flask(__name__)

app.secret_key = "forceready_secret_key"

# ============================================================
# DAILY TASK GENERATOR
# ============================================================

def generate_daily_tasks(student_id, readiness_analysis):

    connection = None
    cursor = None

    try:

        connection = get_connection()

        cursor = connection.cursor(
            dictionary=True
        )

        today = datetime.now().date()


        # =================================================
        # CHECK EXISTING TASKS
        # =================================================

        cursor.execute(
            """
            SELECT COUNT(*) AS task_count
            FROM daily_tasks
            WHERE student_id = %s
            AND task_date = %s
            """,
            (
                student_id,
                today
            )
        )

        result = cursor.fetchone()


        if result and result["task_count"] > 0:

            print(
                "Today's tasks already exist."
            )

            return


        # =================================================
        # GET READINESS SCORES
        # =================================================

        fitness_score = float(
            readiness_analysis.get(
                "fitness_score",
                0
            ) or 0
        )

        progress_score = float(
            readiness_analysis.get(
                "progress_score",
                0
            ) or 0
        )

        overall_score = float(
            readiness_analysis.get(
                "overall_score",
                0
            ) or 0
        )


        # =================================================
        # TASK LIST
        # =================================================

        tasks = []


        # -------------------------------------------------
        # FITNESS
        # -------------------------------------------------

        if fitness_score < 60:

            tasks.append(
                (
                    "Complete a fitness training session",
                    "Fitness",
                    "Complete a suitable fitness session according to your current training and recovery status."
                )
            )

        else:

            tasks.append(
                (
                    "Maintain your fitness routine",
                    "Fitness",
                    "Complete your planned fitness activity and maintain your training consistency."
                )
            )


        # -------------------------------------------------
        # NCC
        # -------------------------------------------------

        if progress_score < 60:

            tasks.append(
                (
                    "Complete NCC preparation",
                    "NCC",
                    "Spend time reviewing NCC topics, training material or planned NCC activities."
                )
            )

        else:

            tasks.append(
                (
                    "Review NCC knowledge",
                    "NCC",
                    "Revise important NCC concepts and preparation material."
                )
            )


        # -------------------------------------------------
        # CAREER
        # -------------------------------------------------

        if overall_score < 70:

            tasks.append(
                (
                    "Complete defence career preparation",
                    "Career",
                    "Spend time preparing for your selected defence career path or SSB preparation."
                )
            )

        else:

            tasks.append(
                (
                    "Practice SSB preparation",
                    "Career",
                    "Complete a short SSB preparation activity such as reasoning, communication or interview practice."
                )
            )


        # -------------------------------------------------
        # PROGRESS
        # -------------------------------------------------

        tasks.append(
            (
                "Update today's progress",
                "Progress",
                "Record your fitness activity, sleep, diet adherence and other relevant daily progress."
            )
        )


        # =================================================
        # INSERT TASKS
        # =================================================

        for task in tasks:

            cursor.execute(
                """
                INSERT INTO daily_tasks
                (
                    student_id,
                    task_date,
                    task_title,
                    category,
                    description,
                    status
                )
                VALUES
                (
                    %s,
                    %s,
                    %s,
                    %s,
                    %s,
                    'Pending'
                )
                """,
                (
                    student_id,
                    today,
                    task[0],
                    task[1],
                    task[2]
                )
            )


        connection.commit()


        print(
            "SUCCESS: Daily tasks generated for",
            today
        )


    except Exception as error:

        print(
            "DAILY TASK ERROR:",
            error
        )

        if connection:

            connection.rollback()


    finally:

        if cursor:

            cursor.close()

        if connection:

            connection.close()


# =====================================================
# HOME
# =====================================================

@app.route("/")
def index():

    return render_template("index.html")


# =====================================================
# NCC MODULE
# =====================================================

@app.route("/ncc")
def ncc():

    return render_template("ncc.html")


@app.route("/army")
def army():

    return render_template("army.html")


@app.route("/navy")
def navy():

    return render_template("navy.html")


@app.route("/air")
def air():

    return render_template("air.html")


# =====================================================
# CERTIFICATES
# =====================================================

@app.route("/certificates", methods=["GET", "POST"])
def certificates():

    connection = None
    cursor = None

    logged_in = "student_id" in session

    try:

        # -------------------------------------------------
        # DATABASE CONNECTION
        # -------------------------------------------------

        connection = get_connection()

        cursor = connection.cursor(
            dictionary=True
        )

        # =================================================
        # ADD CERTIFICATE
        # =================================================

        if request.method == "POST":

            # -------------------------------------------------
            # LOGIN REQUIRED
            # -------------------------------------------------

            if "student_id" not in session:

                return redirect(
                    url_for("login")
                )

            # -------------------------------------------------
            # GET FORM DATA
            # -------------------------------------------------

            certificate_type = request.form.get(
                "certificate_type"
            )

            certificate_number = request.form.get(
                "certificate_number"
            )

            issue_year = request.form.get(
                "issue_year"
            )

            grade = request.form.get(
                "grade"
            )

            issuing_authority = request.form.get(
                "issuing_authority"
            )

            description = request.form.get(
                "description"
            )

            # =================================================
            # VALIDATION
            # =================================================

            if not certificate_type:

                return render_template(
                    "certificates.html",
                    certificates=[],
                    logged_in=True,
                    error="Please select the certificate type."
                )

            # -------------------------------------------------
            # YEAR VALIDATION
            # -------------------------------------------------

            if issue_year:

                try:

                    issue_year = int(
                        issue_year
                    )

                except ValueError:

                    return render_template(
                        "certificates.html",
                        certificates=[],
                        logged_in=True,
                        error="Certificate issue year must be a valid year."
                    )

            else:

                issue_year = None

            # =================================================
            # INSERT CERTIFICATE
            # =================================================

            insert_query = """
                INSERT INTO certificate_records
                (
                    student_id,
                    certificate_type,
                    certificate_number,
                    issue_year,
                    grade,
                    issuing_authority,
                    description
                )
                VALUES
                (
                    %s,
                    %s,
                    %s,
                    %s,
                    %s,
                    %s,
                    %s
                )
            """

            cursor.execute(
                insert_query,
                (
                    session["student_id"],
                    certificate_type,
                    certificate_number,
                    issue_year,
                    grade,
                    issuing_authority,
                    description
                )
            )

            connection.commit()

        # =================================================
        # GET PERSONAL CERTIFICATE RECORDS
        # =================================================

        certificate_records = []

        if "student_id" in session:

            select_query = """
                SELECT
                    id,
                    certificate_type,
                    certificate_number,
                    issue_year,
                    grade,
                    issuing_authority,
                    description,
                    created_at
                FROM certificate_records
                WHERE student_id = %s
                ORDER BY
                    issue_year DESC,
                    id DESC
            """

            cursor.execute(
                select_query,
                (session["student_id"],)
            )

            certificate_records = cursor.fetchall()

        # =================================================
        # DISPLAY CERTIFICATE PAGE
        # =================================================

        return render_template(
            "certificates.html",
            certificates=certificate_records,
            logged_in=logged_in
        )

    except Exception as error:

        if connection:
            connection.rollback()

        print(
            "Certificate Error:",
            error
        )

        return render_template(
            "certificates.html",
            certificates=[],
            logged_in=logged_in,
            error=f"Certificate loading failed: {error}"
        )

    finally:

        if cursor:
            cursor.close()

        if connection:
            connection.close()


# =====================================================
# NCC CAMPS
# =====================================================

@app.route("/camps", methods=["GET", "POST"])
def camps():

    connection = None
    cursor = None

    logged_in = "student_id" in session

    try:

        # -------------------------------------------------
        # DATABASE CONNECTION
        # -------------------------------------------------

        connection = get_connection()

        cursor = connection.cursor(
            dictionary=True
        )

        # =================================================
        # ADD CAMP PARTICIPATION
        # =================================================

        if request.method == "POST":

            # -------------------------------------------------
            # LOGIN REQUIRED
            # -------------------------------------------------

            if "student_id" not in session:

                return redirect(
                    url_for("login")
                )

            # -------------------------------------------------
            # GET FORM DATA
            # -------------------------------------------------

            camp_name = request.form.get(
                "camp_name"
            )

            camp_type = request.form.get(
                "camp_type"
            )

            camp_level = request.form.get(
                "camp_level"
            )

            participation_year = request.form.get(
                "participation_year"
            )

            participation_status = request.form.get(
                "participation_status"
            )

            achievement = request.form.get(
                "achievement"
            )

            description = request.form.get(
                "description"
            )

            # =================================================
            # REQUIRED FIELD VALIDATION
            # =================================================

            if not camp_name:

                return render_template(
                    "camps.html",
                    camps=[],
                    logged_in=True,
                    error="Please enter the camp name."
                )

            if not camp_type:

                return render_template(
                    "camps.html",
                    camps=[],
                    logged_in=True,
                    error="Please select the camp type."
                )

            # =================================================
            # YEAR VALIDATION
            # =================================================

            if participation_year:

                try:

                    participation_year = int(
                        participation_year
                    )

                except ValueError:

                    return render_template(
                        "camps.html",
                        camps=[],
                        logged_in=True,
                        error="Participation year must be a valid year."
                    )

            else:

                participation_year = None

            # =================================================
            # INSERT CAMP RECORD
            # =================================================

            insert_query = """
                INSERT INTO camp_records
                (
                    student_id,
                    camp_name,
                    camp_type,
                    camp_level,
                    participation_year,
                    participation_status,
                    achievement,
                    description
                )
                VALUES
                (
                    %s,
                    %s,
                    %s,
                    %s,
                    %s,
                    %s,
                    %s,
                    %s
                )
            """

            cursor.execute(
                insert_query,
                (
                    session["student_id"],
                    camp_name,
                    camp_type,
                    camp_level,
                    participation_year,
                    participation_status,
                    achievement,
                    description
                )
            )

            connection.commit()

        # =================================================
        # GET PERSONAL CAMP RECORDS
        # =================================================

        camp_records = []

        if "student_id" in session:

            select_query = """
                SELECT
                    id,
                    camp_name,
                    camp_type,
                    camp_level,
                    participation_year,
                    participation_status,
                    achievement,
                    description,
                    created_at
                FROM camp_records
                WHERE student_id = %s
                ORDER BY
                    participation_year DESC,
                    id DESC
            """

            cursor.execute(
                select_query,
                (session["student_id"],)
            )

            camp_records = cursor.fetchall()

        # =================================================
        # DISPLAY CAMPS PAGE
        # =================================================

        return render_template(
            "camps.html",
            camps=camp_records,
            logged_in=logged_in
        )

    except Exception as error:

        if connection:
            connection.rollback()

        print(
            "Camp Error:",
            error
        )

        return render_template(
            "camps.html",
            camps=[],
            logged_in=logged_in,
            error=f"Camp loading failed: {error}"
        )

    finally:

        if cursor:
            cursor.close()

        if connection:
            connection.close()


# =====================================================
# NCC LOCATOR
# =====================================================

@app.route("/locator")
def locator():

    # -------------------------------------------------
    # LOGIN CHECK
    # -------------------------------------------------

    if "student_id" not in session:

        return redirect(
            url_for("login")
        )

    connection = None
    cursor = None

    try:

        # -------------------------------------------------
        # DATABASE CONNECTION
        # -------------------------------------------------

        connection = get_connection()

        cursor = connection.cursor(
            dictionary=True
        )

        # -------------------------------------------------
        # GET SELECTED WING
        # -------------------------------------------------

        wing = request.args.get(
            "wing"
        )

        # -------------------------------------------------
        # FILTER BY WING
        # -------------------------------------------------

        if wing:

            query = """
                SELECT
                    id,
                    college_name,
                    unit_name,
                    wing,
                    address,
                    city,
                    contact
                FROM ncc_locations
                WHERE city = %s
                AND wing = %s
                ORDER BY college_name
            """

            cursor.execute(
                query,
                ("Mumbai", wing)
            )

        # -------------------------------------------------
        # SHOW ALL MUMBAI LOCATIONS
        # -------------------------------------------------

        else:

            query = """
                SELECT
                    id,
                    college_name,
                    unit_name,
                    wing,
                    address,
                    city,
                    contact
                FROM ncc_locations
                WHERE city = %s
                ORDER BY college_name
            """

            cursor.execute(
                query,
                ("Mumbai",)
            )

        # -------------------------------------------------
        # GET RESULTS
        # -------------------------------------------------

        locations = cursor.fetchall()

        # -------------------------------------------------
        # SEND DATA TO HTML
        # -------------------------------------------------

        return render_template(
            "locator.html",
            locations=locations,
            selected_wing=wing
        )

    except Exception as error:

        print(
            "Locator Error:",
            error
        )

        return f"Locator loading failed: {error}"

    finally:

        if cursor:
            cursor.close()

        if connection:
            connection.close()


# =====================================================
# REGISTER
# =====================================================

@app.route("/register", methods=["GET", "POST"])
def register():

    if request.method == "POST":

        # -------------------------------------------------
        # GET FORM DATA
        # -------------------------------------------------

        name = request.form.get("name")
        email = request.form.get("email")
        password = request.form.get("password")
        phone = request.form.get("phone")
        address = request.form.get("address")
        city = request.form.get("city")
        education = request.form.get("education")
        age = request.form.get("age")
        gender = request.form.get("gender")
        preferred_wing = request.form.get("preferred_wing")
        career_goal = request.form.get("career_goal")

        # -------------------------------------------------
        # REQUIRED FIELD VALIDATION
        # -------------------------------------------------

        if not name or not email or not password:

            return render_template(
                "register.html",
                error="Name, email and password are required."
            )

        # -------------------------------------------------
        # AGE VALIDATION
        # -------------------------------------------------

        if age:

            try:

                age = int(age)

            except ValueError:

                return render_template(
                    "register.html",
                    error="Age must be a number."
                )

        else:

            age = None

        # -------------------------------------------------
        # HASH PASSWORD
        # -------------------------------------------------

        hashed_password = generate_password_hash(
            password
        )

        connection = None
        cursor = None

        try:

            # -------------------------------------------------
            # DATABASE CONNECTION
            # -------------------------------------------------

            connection = get_connection()

            cursor = connection.cursor()

            # -------------------------------------------------
            # INSERT STUDENT
            # -------------------------------------------------

            query = """
                INSERT INTO students
                (
                    name,
                    email,
                    password,
                    phone,
                    address,
                    city,
                    education,
                    age,
                    gender,
                    preferred_wing,
                    career_goal
                )
                VALUES
                (
                    %s,
                    %s,
                    %s,
                    %s,
                    %s,
                    %s,
                    %s,
                    %s,
                    %s,
                    %s,
                    %s
                )
            """

            values = (
                name,
                email,
                hashed_password,
                phone,
                address,
                city,
                education,
                age,
                gender,
                preferred_wing,
                career_goal
            )

            cursor.execute(
                query,
                values
            )

            connection.commit()

            print(
                "Student registered successfully!"
            )

            # -------------------------------------------------
            # GO TO LOGIN
            # -------------------------------------------------

            return redirect(
                url_for("login")
            )

        except Exception as error:

            if connection:
                connection.rollback()

            print(
                "Registration Error:",
                error
            )

            return render_template(
                "register.html",
                error=f"Registration failed: {error}"
            )

        finally:

            if cursor:
                cursor.close()

            if connection:
                connection.close()

    return render_template(
        "register.html"
    )


# =====================================================
# LOGIN
# =====================================================

@app.route("/login", methods=["GET", "POST"])
def login():

    if request.method == "POST":

        email = request.form.get(
            "email"
        )

        password = request.form.get(
            "password"
        )

        connection = None
        cursor = None

        try:

            # -------------------------------------------------
            # DATABASE CONNECTION
            # -------------------------------------------------

            connection = get_connection()

            cursor = connection.cursor(
                dictionary=True
            )

            # -------------------------------------------------
            # FIND STUDENT
            # -------------------------------------------------

            query = """
                SELECT *
                FROM students
                WHERE email = %s
            """

            cursor.execute(
                query,
                (email,)
            )

            student = cursor.fetchone()

            # -------------------------------------------------
            # CHECK PASSWORD
            # -------------------------------------------------

            if student and check_password_hash(
                student["password"],
                password
            ):

                # -------------------------------------------------
                # CREATE SESSION
                # -------------------------------------------------

                session["student_id"] = student["id"]
                session["student_name"] = student["name"]
                session["student_email"] = student["email"]

                # -------------------------------------------------
                # GO TO DASHBOARD
                # -------------------------------------------------

                return redirect(
                    url_for("dashboard")
                )

            else:

                return render_template(
                    "login.html",
                    error="Invalid email or password."
                )

        except Exception as error:

            print(
                "Login Error:",
                error
            )

            return render_template(
                "login.html",
                error=f"Login failed: {error}"
            )

        finally:

            if cursor:
                cursor.close()

            if connection:
                connection.close()

    return render_template(
        "login.html"
    )


# =====================================================
# DASHBOARD
# =====================================================

@app.route("/dashboard")
def dashboard():

    # -------------------------------------------------
    # LOGIN CHECK
    # -------------------------------------------------

    if "student_id" not in session:

        return redirect(
            url_for("login")
        )

    connection = None
    cursor = None

    try:

        # -------------------------------------------------
        # DATABASE CONNECTION
        # -------------------------------------------------

        connection = get_connection()

        cursor = connection.cursor(
            dictionary=True
        )

        # -------------------------------------------------
        # GET LATEST READINESS SCORE
        # -------------------------------------------------

        cursor.execute(
            """
            SELECT
                overall_score
            FROM readiness_history
            WHERE student_id = %s
            ORDER BY readiness_date DESC, id DESC
            LIMIT 1
            """,
            (session["student_id"],)
        )

        readiness_record = cursor.fetchone()

        # -------------------------------------------------
        # DEFAULT READINESS
        # -------------------------------------------------

        readiness_score = 0

        if readiness_record:

            readiness_score = (
                readiness_record["overall_score"]
                or 0
            )

        # -------------------------------------------------
        # DISPLAY DASHBOARD
        # -------------------------------------------------

        return render_template(
            "dashboard.html",
            student_name=session["student_name"],
            readiness_score=readiness_score
        )

    except Exception as error:

        print(
            "Dashboard Error:",
            error
        )

        return render_template(
            "dashboard.html",
            student_name=session["student_name"],
            readiness_score=0
        )

    finally:

        if cursor:
            cursor.close()

        if connection:
            connection.close()
# =====================================================
# STUDENT PROFILE
# =====================================================

@app.route("/profile")
def profile():

    # -------------------------------------------------
    # LOGIN CHECK
    # -------------------------------------------------

    if "student_id" not in session:

        return redirect(
            url_for("login")
        )

    connection = None
    cursor = None

    try:

        # -------------------------------------------------
        # DATABASE CONNECTION
        # -------------------------------------------------

        connection = get_connection()

        cursor = connection.cursor(
            dictionary=True
        )

        # -------------------------------------------------
        # GET LOGGED-IN STUDENT
        # -------------------------------------------------

        query = """
            SELECT
                id,
                name,
                email,
                phone,
                address,
                city,
                education,
                age,
                gender,
                preferred_wing,
                career_goal,
                created_at
            FROM students
            WHERE id = %s
        """

        cursor.execute(
            query,
            (session["student_id"],)
        )

        student = cursor.fetchone()

        # -------------------------------------------------
        # STUDENT NOT FOUND
        # -------------------------------------------------

        if not student:

            session.clear()

            return redirect(
                url_for("login")
            )

        # -------------------------------------------------
        # DISPLAY PROFILE
        # -------------------------------------------------

        return render_template(
            "profile.html",
            student=student
        )

    except Exception as error:

        print(
            "Profile Error:",
            error
        )

        return f"Profile loading failed: {error}"

    finally:

        if cursor:
            cursor.close()

        if connection:
            connection.close()

# =====================================================
# SPORTS
# =====================================================

@app.route("/sports", methods=["GET", "POST"])
def sports():

    # -------------------------------------------------
    # LOGIN CHECK
    # -------------------------------------------------

    if "student_id" not in session:

        return redirect(
            url_for("login")
        )

    connection = None
    cursor = None

    try:

        # -------------------------------------------------
        # DATABASE CONNECTION
        # -------------------------------------------------

        connection = get_connection()

        cursor = connection.cursor(
            dictionary=True
        )

        # =================================================
        # ADD SPORTS ACHIEVEMENT
        # =================================================

        if request.method == "POST":

            # -------------------------------------------------
            # GET FORM DATA
            # -------------------------------------------------

            sport_name = request.form.get(
                "sport_name"
            )

            sport_level = request.form.get(
                "sport_level"
            )

            achievement = request.form.get(
                "achievement"
            )

            position = request.form.get(
                "position"
            )

            achievement_year = request.form.get(
                "achievement_year"
            )

            participation_type = request.form.get(
                "participation_type"
            )

            description = request.form.get(
                "description"
            )

            # =================================================
            # VALIDATION
            # =================================================

            if not sport_name:

                return render_template(
                    "sports.html",
                    sports=[],
                    error="Please enter the sport name."
                )

            if not sport_level:

                return render_template(
                    "sports.html",
                    sports=[],
                    error="Please select the sport level."
                )

            # =================================================
            # YEAR VALIDATION
            # =================================================

            if achievement_year:

                try:

                    achievement_year = int(
                        achievement_year
                    )

                except ValueError:

                    return render_template(
                        "sports.html",
                        sports=[],
                        error="Achievement year must be a valid year."
                    )

            else:

                achievement_year = None

            # =================================================
            # INSERT SPORTS RECORD
            # =================================================

            insert_query = """
                INSERT INTO sports_records
                (
                    student_id,
                    sport_name,
                    sport_level,
                    achievement,
                    position,
                    achievement_year,
                    participation_type,
                    description
                )
                VALUES
                (
                    %s,
                    %s,
                    %s,
                    %s,
                    %s,
                    %s,
                    %s,
                    %s
                )
            """

            cursor.execute(
                insert_query,
                (
                    session["student_id"],
                    sport_name,
                    sport_level,
                    achievement,
                    position,
                    achievement_year,
                    participation_type,
                    description
                )
            )

            # -------------------------------------------------
            # SAVE CHANGES
            # -------------------------------------------------

            connection.commit()

        # =================================================
        # GET SPORTS HISTORY
        # =================================================

        select_query = """
            SELECT
                id,
                sport_name,
                sport_level,
                achievement,
                position,
                achievement_year,
                participation_type,
                description,
                created_at
            FROM sports_records
            WHERE student_id = %s
            ORDER BY
                achievement_year DESC,
                id DESC
        """

        cursor.execute(
            select_query,
            (session["student_id"],)
        )

        sports_records = cursor.fetchall()

        # =================================================
        # DISPLAY SPORTS PAGE
        # =================================================

        return render_template(
            "sports.html",
            sports=sports_records
        )

    except Exception as error:

        if connection:
            connection.rollback()

        print(
            "Sports Error:",
            error
        )

        return render_template(
            "sports.html",
            sports=[],
            error=f"Sports loading failed: {error}"
        )

    finally:

        if cursor:
            cursor.close()

        if connection:
            connection.close()


# =====================================================
# FITNESS
# =====================================================

@app.route("/fitness", methods=["GET", "POST"])
def fitness():

    # -------------------------------------------------
    # LOGIN CHECK
    # -------------------------------------------------

    if "student_id" not in session:

        return redirect(
            url_for("login")
        )

    connection = None
    cursor = None

    try:

        # -------------------------------------------------
        # DATABASE CONNECTION
        # -------------------------------------------------

        connection = get_connection()

        cursor = connection.cursor(
            dictionary=True
        )

        # =================================================
        # SAVE FITNESS DATA
        # =================================================

        if request.method == "POST":

            running_distance = request.form.get(
                "running_distance"
            )

            pushups = request.form.get(
                "pushups"
            )

            situps = request.form.get(
                "situps"
            )

            workout_days = request.form.get(
                "workout_days"
            )

            workout_duration = request.form.get(
                "workout_duration"
            )

            fitness_goal = request.form.get(
                "fitness_goal"
            )

            training_level = request.form.get(
                "training_level"
            )

            # =================================================
            # REQUIRED FIELD VALIDATION
            # =================================================

            if not fitness_goal:

                return render_template(
                    "fitness.html",
                    fitness=None,
                    injury=None,
                    plan=None,
                    error="Please select your fitness goal."
                )

            if not training_level:

                return render_template(
                    "fitness.html",
                    fitness=None,
                    injury=None,
                    plan=None,
                    error="Please select your training level."
                )

            # =================================================
            # CONVERT VALUES
            # =================================================

            try:

                running_distance = float(
                    running_distance
                )

                pushups = int(
                    pushups
                )

                situps = int(
                    situps
                )

                workout_days = int(
                    workout_days
                )

                workout_duration = int(
                    workout_duration
                )

            except (ValueError, TypeError):

                return render_template(
                    "fitness.html",
                    fitness=None,
                    injury=None,
                    plan=None,
                    error="Please enter valid fitness values."
                )

            # =================================================
            # VALIDATION
            # =================================================

            if running_distance < 0:

                return render_template(
                    "fitness.html",
                    fitness=None,
                    injury=None,
                    plan=None,
                    error="Running distance cannot be negative."
                )

            if pushups < 0:

                return render_template(
                    "fitness.html",
                    fitness=None,
                    injury=None,
                    plan=None,
                    error="Push-ups cannot be negative."
                )

            if situps < 0:

                return render_template(
                    "fitness.html",
                    fitness=None,
                    injury=None,
                    plan=None,
                    error="Sit-ups cannot be negative."
                )

            if workout_days < 0 or workout_days > 7:

                return render_template(
                    "fitness.html",
                    fitness=None,
                    injury=None,
                    plan=None,
                    error="Workout days must be between 0 and 7."
                )

            if workout_duration < 0:

                return render_template(
                    "fitness.html",
                    fitness=None,
                    injury=None,
                    plan=None,
                    error="Workout duration cannot be negative."
                )

            # =================================================
            # CHECK EXISTING FITNESS RECORD
            # =================================================

            check_query = """
                SELECT id
                FROM fitness_records
                WHERE student_id = %s
                ORDER BY id DESC
                LIMIT 1
            """

            cursor.execute(
                check_query,
                (session["student_id"],)
            )

            existing_record = cursor.fetchone()

            # =================================================
            # UPDATE EXISTING RECORD
            # =================================================

            if existing_record:

                update_query = """
                    UPDATE fitness_records
                    SET
                        running_distance = %s,
                        pushups = %s,
                        situps = %s,
                        workout_days = %s,
                        workout_duration = %s,
                        fitness_goal = %s,
                        training_level = %s
                    WHERE id = %s
                """

                cursor.execute(
                    update_query,
                    (
                        running_distance,
                        pushups,
                        situps,
                        workout_days,
                        workout_duration,
                        fitness_goal,
                        training_level,
                        existing_record["id"]
                    )
                )

            # =================================================
            # INSERT NEW FITNESS RECORD
            # =================================================

            else:

                insert_query = """
                    INSERT INTO fitness_records
                    (
                        student_id,
                        running_distance,
                        pushups,
                        situps,
                        workout_days,
                        workout_duration,
                        fitness_goal,
                        training_level
                    )
                    VALUES
                    (
                        %s,
                        %s,
                        %s,
                        %s,
                        %s,
                        %s,
                        %s,
                        %s
                    )
                """

                cursor.execute(
                    insert_query,
                    (
                        session["student_id"],
                        running_distance,
                        pushups,
                        situps,
                        workout_days,
                        workout_duration,
                        fitness_goal,
                        training_level
                    )
                )

            # -------------------------------------------------
            # SAVE FITNESS DATA
            # -------------------------------------------------

            connection.commit()

        # =================================================
        # GET CURRENT FITNESS DATA
        # =================================================

        select_fitness_query = """
            SELECT
                id,
                running_distance,
                pushups,
                situps,
                workout_days,
                workout_duration,
                fitness_goal,
                training_level,
                created_at
            FROM fitness_records
            WHERE student_id = %s
            ORDER BY id DESC
            LIMIT 1
        """

        cursor.execute(
            select_fitness_query,
            (session["student_id"],)
        )

        fitness_record = cursor.fetchone()

        # =================================================
        # GET CURRENT INJURY DATA
        # =================================================

        select_injury_query = """
            SELECT
                id,
                injury_type,
                body_part,
                specific_injury,
                injury_date,
                severity,
                surgery,
                pain_level,
                swelling,
                medical_clearance,
                recovery_status,
                description,
                created_at
            FROM injury_records
            WHERE student_id = %s
            ORDER BY id DESC
            LIMIT 1
        """

        cursor.execute(
            select_injury_query,
            (session["student_id"],)
        )

        injury_record = cursor.fetchone()

        # =================================================
        # GENERATE AI FITNESS PLAN
        # =================================================

        plan = generate_fitness_recommendations(
            fitness_record,
            injury_record
        )

        # =================================================
        # DISPLAY FITNESS PAGE
        # =================================================

        return render_template(
            "fitness.html",
            fitness=fitness_record,
            injury=injury_record,
            plan=plan
        )

    # =====================================================
    # ERROR HANDLING
    # =====================================================

    except Exception as error:

        if connection:
            connection.rollback()

        print(
            "Fitness Error:",
            error
        )

        return render_template(
            "fitness.html",
            fitness=None,
            injury=None,
            plan=None,
            error=f"Fitness loading failed: {error}"
        )

    # =====================================================
    # CLOSE DATABASE
    # =====================================================

    finally:

        if cursor:
            cursor.close()

        if connection:
            connection.close()


# =====================================================
# INJURY
# =====================================================

@app.route("/injury", methods=["GET", "POST"])
def injury():

    # -------------------------------------------------
    # LOGIN CHECK
    # -------------------------------------------------

    if "student_id" not in session:

        return redirect(
            url_for("login")
        )

    connection = None
    cursor = None

    try:

        # -------------------------------------------------
        # DATABASE CONNECTION
        # -------------------------------------------------

        connection = get_connection()

        cursor = connection.cursor(
            dictionary=True
        )

        # =================================================
        # SAVE INJURY INFORMATION
        # =================================================

        if request.method == "POST":

            # -------------------------------------------------
            # GET FORM DATA
            # -------------------------------------------------

            injury_type = request.form.get(
                "injury_type"
            )

            body_part = request.form.get(
                "body_part"
            )

            specific_injury = request.form.get(
                "specific_injury"
            )

            injury_date = request.form.get(
                "injury_date"
            )

            severity = request.form.get(
                "severity"
            )

            surgery = request.form.get(
                "surgery"
            )

            pain_level = request.form.get(
                "pain_level"
            )

            swelling = request.form.get(
                "swelling"
            )

            medical_clearance = request.form.get(
                "medical_clearance"
            )

            recovery_status = request.form.get(
                "recovery_status"
            )

            description = request.form.get(
                "description"
            )

            # =================================================
            # REQUIRED FIELD VALIDATION
            # =================================================

            if not injury_type:

                return render_template(
                    "injury.html",
                    injury=None,
                    error="Please select the injury type."
                )

            if not body_part:

                return render_template(
                    "injury.html",
                    injury=None,
                    error="Please select the affected body part."
                )

            if not injury_date:

                return render_template(
                    "injury.html",
                    injury=None,
                    error="Please select the injury date."
                )

            if not severity:

                return render_template(
                    "injury.html",
                    injury=None,
                    error="Please select the injury severity."
                )

            if not surgery:

                return render_template(
                    "injury.html",
                    injury=None,
                    error="Please select whether surgery was performed."
                )

            if not swelling:

                return render_template(
                    "injury.html",
                    injury=None,
                    error="Please select the swelling status."
                )

            if not medical_clearance:

                return render_template(
                    "injury.html",
                    injury=None,
                    error="Please select your medical clearance status."
                )

            if not recovery_status:

                return render_template(
                    "injury.html",
                    injury=None,
                    error="Please select your recovery status."
                )

            # =================================================
            # PAIN LEVEL VALIDATION
            # =================================================

            try:

                pain_level = int(
                    pain_level
                )

            except (ValueError, TypeError):

                return render_template(
                    "injury.html",
                    injury=None,
                    error="Pain level must be a number between 0 and 10."
                )

            if pain_level < 0 or pain_level > 10:

                return render_template(
                    "injury.html",
                    injury=None,
                    error="Pain level must be between 0 and 10."
                )

            # =================================================
            # CHECK EXISTING INJURY
            # =================================================

            check_query = """
                SELECT id
                FROM injury_records
                WHERE student_id = %s
                ORDER BY id DESC
                LIMIT 1
            """

            cursor.execute(
                check_query,
                (session["student_id"],)
            )

            existing_injury = cursor.fetchone()

            # =================================================
            # UPDATE EXISTING INJURY
            # =================================================

            if existing_injury:

                update_query = """
                    UPDATE injury_records
                    SET
                        injury_type = %s,
                        body_part = %s,
                        specific_injury = %s,
                        injury_date = %s,
                        severity = %s,
                        surgery = %s,
                        pain_level = %s,
                        swelling = %s,
                        medical_clearance = %s,
                        recovery_status = %s,
                        description = %s
                    WHERE id = %s
                """

                cursor.execute(
                    update_query,
                    (
                        injury_type,
                        body_part,
                        specific_injury,
                        injury_date,
                        severity,
                        surgery,
                        pain_level,
                        swelling,
                        medical_clearance,
                        recovery_status,
                        description,
                        existing_injury["id"]
                    )
                )

            # =================================================
            # CREATE NEW INJURY
            # =================================================

            else:

                insert_query = """
                    INSERT INTO injury_records
                    (
                        student_id,
                        injury_type,
                        body_part,
                        specific_injury,
                        injury_date,
                        severity,
                        surgery,
                        pain_level,
                        swelling,
                        medical_clearance,
                        recovery_status,
                        description
                    )
                    VALUES
                    (
                        %s,
                        %s,
                        %s,
                        %s,
                        %s,
                        %s,
                        %s,
                        %s,
                        %s,
                        %s,
                        %s,
                        %s
                    )
                """

                cursor.execute(
                    insert_query,
                    (
                        session["student_id"],
                        injury_type,
                        body_part,
                        specific_injury,
                        injury_date,
                        severity,
                        surgery,
                        pain_level,
                        swelling,
                        medical_clearance,
                        recovery_status,
                        description
                    )
                )

            # -------------------------------------------------
            # SAVE DATABASE CHANGES
            # -------------------------------------------------

            connection.commit()

        # =================================================
        # GET CURRENT INJURY
        # =================================================

        select_query = """
            SELECT
                id,
                injury_type,
                body_part,
                specific_injury,
                injury_date,
                severity,
                surgery,
                pain_level,
                swelling,
                medical_clearance,
                recovery_status,
                description,
                created_at
            FROM injury_records
            WHERE student_id = %s
            ORDER BY id DESC
            LIMIT 1
        """

        cursor.execute(
            select_query,
            (session["student_id"],)
        )

        injury_record = cursor.fetchone()

        # =================================================
        # DISPLAY INJURY PAGE
        # =================================================

        return render_template(
            "injury.html",
            injury=injury_record
        )

    # =====================================================
    # ERROR HANDLING
    # =====================================================

    except Exception as error:

        if connection:
            connection.rollback()

        print(
            "Injury Error:",
            error
        )

        return render_template(
            "injury.html",
            injury=None,
            error=f"Injury loading failed: {error}"
        )

    # =====================================================
    # CLOSE DATABASE
    # =====================================================

    finally:

        if cursor:
            cursor.close()

        if connection:
            connection.close()

# =====================================================
# SAVE READINESS HISTORY
# =====================================================

def save_daily_readiness(student_id, readiness_date):
    """
    Calculate the student's readiness for the selected
    progress date and save/update the readiness history.
    """

    connection = None
    cursor = None

    try:

        # =================================================
        # DATABASE CONNECTION
        # =================================================

        connection = get_connection()
        cursor = connection.cursor(dictionary=True)


        # =================================================
        # STUDENT
        # =================================================

        cursor.execute(
            """
            SELECT
                id,
                name,
                education,
                age,
                preferred_wing,
                career_goal,
                diet_preference
            FROM students
            WHERE id = %s
            """,
            (student_id,)
        )

        student = cursor.fetchone()


        if not student:

            print(
                "Readiness Error: Student not found."
            )

            return None


        # =================================================
        # FITNESS
        # =================================================

        cursor.execute(
            """
            SELECT
                running_distance,
                pushups,
                situps,
                workout_days,
                workout_duration,
                fitness_goal,
                training_level
            FROM fitness_records
            WHERE student_id = %s
            ORDER BY id DESC
            LIMIT 1
            """,
            (student_id,)
        )

        fitness = cursor.fetchone()


        # =================================================
        # INJURY
        # =================================================

        cursor.execute(
            """
            SELECT
                injury_type,
                body_part,
                severity,
                medical_clearance,
                recovery_status,
                pain_level,
                swelling
            FROM injury_records
            WHERE student_id = %s
            ORDER BY id DESC
            LIMIT 1
            """,
            (student_id,)
        )

        injury = cursor.fetchone()


        # =================================================
        # SPORTS
        # =================================================

        cursor.execute(
            """
            SELECT
                sport_name,
                sport_level,
                achievement,
                position,
                achievement_year,
                participation_type
            FROM sports_records
            WHERE student_id = %s
            ORDER BY achievement_year DESC, id DESC
            """,
            (student_id,)
        )

        sports = cursor.fetchall()


        # =================================================
        # CERTIFICATES
        # =================================================

        cursor.execute(
            """
            SELECT
                certificate_type,
                certificate_number,
                issue_year,
                grade,
                issuing_authority
            FROM certificate_records
            WHERE student_id = %s
            ORDER BY issue_year DESC, id DESC
            """,
            (student_id,)
        )

        certificates = cursor.fetchall()


        # =================================================
        # CAMPS
        # =================================================

        cursor.execute(
            """
            SELECT
                camp_name,
                camp_type,
                camp_level,
                participation_year,
                participation_status,
                achievement
            FROM camp_records
            WHERE student_id = %s
            ORDER BY participation_year DESC, id DESC
            """,
            (student_id,)
        )

        camps = cursor.fetchall()


        # =================================================
        # PROGRESS
        # =================================================
        #
        # IMPORTANT:
        # Only progress records up to the selected date
        # are used for that day's readiness score.
        #

        cursor.execute(
            """
            SELECT
                progress_date,
                running_distance,
                pushups,
                situps,
                workout_duration,
                workout_days,
                diet_adherence,
                sleep_hours,
                ncc_participation,
                recovery_status
            FROM progress_records
            WHERE student_id = %s
              AND progress_date <= %s
            ORDER BY progress_date ASC, id ASC
            """,
            (
                student_id,
                readiness_date
            )
        )

        progress = cursor.fetchall()


        # =================================================
        # AI READINESS CALCULATION
        # =================================================

        analysis = generate_readiness_analysis(
            student=student,
            fitness=fitness,
            injury=injury,
            sports=sports,
            certificates=certificates,
            camps=camps,
            progress=progress
        )


        if not analysis:

            print(
                "Readiness Error: No analysis generated."
            )

            return None


        # =================================================
        # SAFE SCORE VALUES
        # =================================================

        overall_score = int(
            analysis.get(
                "overall_score",
                0
            ) or 0
        )

        fitness_score = int(
            analysis.get(
                "fitness_score",
                0
            ) or 0
        )

        sports_score = int(
            analysis.get(
                "sports_score",
                0
            ) or 0
        )

        certificate_score = int(
            analysis.get(
                "certificate_score",
                0
            ) or 0
        )

        camp_score = int(
            analysis.get(
                "camp_score",
                0
            ) or 0
        )

        progress_score = int(
            analysis.get(
                "progress_score",
                0
            ) or 0
        )

        recovery_score = int(
            analysis.get(
                "recovery_score",
                0
            ) or 0
        )


        # =================================================
        # SAVE / UPDATE READINESS HISTORY
        # =================================================

        cursor.execute(
            """
            INSERT INTO readiness_history
            (
                student_id,
                readiness_date,
                overall_score,
                fitness_score,
                sports_score,
                certificate_score,
                camp_score,
                progress_score,
                recovery_score
            )
            VALUES
            (
                %s,
                %s,
                %s,
                %s,
                %s,
                %s,
                %s,
                %s,
                %s
            )

            ON DUPLICATE KEY UPDATE

                overall_score = VALUES(overall_score),

                fitness_score = VALUES(fitness_score),

                sports_score = VALUES(sports_score),

                certificate_score =
                    VALUES(certificate_score),

                camp_score =
                    VALUES(camp_score),

                progress_score =
                    VALUES(progress_score),

                recovery_score =
                    VALUES(recovery_score)
            """,
            (
                student_id,
                readiness_date,
                overall_score,
                fitness_score,
                sports_score,
                certificate_score,
                camp_score,
                progress_score,
                recovery_score
            )
        )


        # =================================================
        # COMMIT
        # =================================================

        connection.commit()


        print(
            "Readiness saved:",
            readiness_date,
            "→",
            overall_score,
            "%"
        )


        return analysis


    except Exception as error:

        if connection:

            connection.rollback()


        print(
            "Readiness History Error:",
            error
        )


        return None


    finally:

        if cursor:

            cursor.close()


        if connection:

            connection.close()


# =====================================================
# PROGRESS TRACKING
# =====================================================

@app.route("/progress", methods=["GET", "POST"])
def progress():

    # -------------------------------------------------
    # LOGIN CHECK
    # -------------------------------------------------

    if "student_id" not in session:
        return redirect(url_for("login"))

    connection = None
    cursor = None

    try:

        # -------------------------------------------------
        # DATABASE CONNECTION
        # -------------------------------------------------

        connection = get_connection()
        cursor = connection.cursor(dictionary=True)

        student_id = session["student_id"]

        # =================================================
        # ADD NEW PROGRESS
        # =================================================

        if request.method == "POST":

            progress_date = request.form.get(
                "progress_date"
            )

            running_distance = request.form.get(
                "running_distance"
            )

            pushups = request.form.get(
                "pushups"
            )

            situps = request.form.get(
                "situps"
            )

            workout_duration = request.form.get(
                "workout_duration"
            )

            workout_days = request.form.get(
                "workout_days"
            )

            diet_adherence = request.form.get(
                "diet_adherence"
            )

            sleep_hours = request.form.get(
                "sleep_hours"
            )

            ncc_participation = request.form.get(
                "ncc_participation"
            )

            recovery_status = request.form.get(
                "recovery_status"
            )

            notes = request.form.get(
                "notes"
            )

            # =================================================
            # VALIDATE DATE
            # =================================================

            if not progress_date:

                return render_template(
                    "progress.html",
                    progress_records=[],
                    latest=None,
                    total_records=0,
                    average_diet=0,
                    average_sleep=0,
                    average_ncc=0,
                    error="Please select a progress date."
                )

            # =================================================
            # CONVERT NUMERIC VALUES
            # =================================================

            try:

                running_distance = (
                    float(running_distance)
                    if running_distance
                    else 0
                )

                pushups = (
                    int(pushups)
                    if pushups
                    else 0
                )

                situps = (
                    int(situps)
                    if situps
                    else 0
                )

                workout_duration = (
                    int(workout_duration)
                    if workout_duration
                    else 0
                )

                workout_days = (
                    int(workout_days)
                    if workout_days
                    else 0
                )

                diet_adherence = (
                    int(diet_adherence)
                    if diet_adherence
                    else 0
                )

                sleep_hours = (
                    float(sleep_hours)
                    if sleep_hours
                    else 0
                )

                ncc_participation = (
                    int(ncc_participation)
                    if ncc_participation
                    else 0
                )

            except ValueError:

                return render_template(
                    "progress.html",
                    progress_records=[],
                    latest=None,
                    total_records=0,
                    average_diet=0,
                    average_sleep=0,
                    average_ncc=0,
                    error="Please enter valid numbers in the progress form."
                )

            # =================================================
            # VALIDATE PERCENTAGES
            # =================================================

            if diet_adherence < 0 or diet_adherence > 100:

                return render_template(
                    "progress.html",
                    progress_records=[],
                    latest=None,
                    total_records=0,
                    average_diet=0,
                    average_sleep=0,
                    average_ncc=0,
                    error="Diet adherence must be between 0 and 100."
                )

            if ncc_participation < 0 or ncc_participation > 100:

                return render_template(
                    "progress.html",
                    progress_records=[],
                    latest=None,
                    total_records=0,
                    average_diet=0,
                    average_sleep=0,
                    average_ncc=0,
                    error="NCC participation must be between 0 and 100."
                )

            # =================================================
            # INSERT PROGRESS
            # =================================================

            insert_query = """
                INSERT INTO progress_records
                (
                    student_id,
                    progress_date,
                    running_distance,
                    pushups,
                    situps,
                    workout_duration,
                    workout_days,
                    diet_adherence,
                    sleep_hours,
                    ncc_participation,
                    recovery_status,
                    notes
                )
                VALUES
                (
                    %s,
                    %s,
                    %s,
                    %s,
                    %s,
                    %s,
                    %s,
                    %s,
                    %s,
                    %s,
                    %s,
                    %s
                )
            """

            cursor.execute(
                insert_query,
                (
                    student_id,
                    progress_date,
                    running_distance,
                    pushups,
                    situps,
                    workout_duration,
                    workout_days,
                    diet_adherence,
                    sleep_hours,
                    ncc_participation,
                    recovery_status,
                    notes
                )
            )

            connection.commit()

            # =================================================
            # UPDATE AI READINESS HISTORY
            # =================================================

            save_daily_readiness(
                student_id,
                progress_date
            )

        # =================================================
        # GET ALL PROGRESS RECORDS
        # =================================================

        cursor.execute(
            """
            SELECT
                id,
                progress_date,
                running_distance,
                pushups,
                situps,
                workout_duration,
                workout_days,
                diet_adherence,
                sleep_hours,
                ncc_participation,
                recovery_status,
                notes,
                created_at
            FROM progress_records
            WHERE student_id = %s
            ORDER BY progress_date DESC, id DESC
            """,
            (student_id,)
        )

        progress_records = cursor.fetchall()

        # =================================================
        # CALCULATE SUMMARY
        # =================================================

        total_records = len(progress_records)

        if total_records > 0:

            latest = progress_records[0]

            average_diet = sum(
                record["diet_adherence"] or 0
                for record in progress_records
            ) / total_records

            average_sleep = sum(
                float(record["sleep_hours"] or 0)
                for record in progress_records
            ) / total_records

            average_ncc = sum(
                record["ncc_participation"] or 0
                for record in progress_records
            ) / total_records

        else:

            latest = None
            average_diet = 0
            average_sleep = 0
            average_ncc = 0

        # =================================================
        # DISPLAY PAGE
        # =================================================

        return render_template(
            "progress.html",
            progress_records=progress_records,
            latest=latest,
            total_records=total_records,
            average_diet=round(
                average_diet,
                1
            ),
            average_sleep=round(
                average_sleep,
                1
            ),
            average_ncc=round(
                average_ncc,
                1
            )
        )

    # =====================================================
    # ERROR HANDLING
    # =====================================================

    except Exception as error:

        if connection:
            connection.rollback()

        print(
            "Progress Error:",
            error
        )

        return render_template(
            "progress.html",
            progress_records=[],
            latest=None,
            total_records=0,
            average_diet=0,
            average_sleep=0,
            average_ncc=0,
            error=f"Progress loading failed: {error}"
        )

    finally:

        if cursor:
            cursor.close()

        if connection:
            connection.close()

# =====================================================
# CAREER GUIDANCE
# =====================================================

@app.route("/career")
def career():

    # -------------------------------------------------
    # LOGIN CHECK
    # -------------------------------------------------

    if "student_id" not in session:

        return redirect(
            url_for("login")
        )

    connection = None
    cursor = None

    try:

        # -------------------------------------------------
        # DATABASE CONNECTION
        # -------------------------------------------------

        connection = get_connection()

        cursor = connection.cursor(
            dictionary=True
        )

        student_id = session["student_id"]

        # =================================================
        # GET STUDENT PROFILE
        # =================================================

        cursor.execute(
            """
            SELECT
                id,
                name,
                email,
                phone,
                address,
                city,
                education,
                age,
                gender,
                preferred_wing,
                career_goal
            FROM students
            WHERE id = %s
            """,
            (student_id,)
        )

        student = cursor.fetchone()

        # -------------------------------------------------
        # STUDENT NOT FOUND
        # -------------------------------------------------

        if not student:

            return redirect(
                url_for("logout")
            )

        # =================================================
        # GET NCC CERTIFICATES
        # =================================================

        cursor.execute(
            """
            SELECT
                id,
                certificate_type,
                certificate_number,
                issue_year,
                grade,
                issuing_authority,
                description,
                created_at
            FROM certificate_records
            WHERE student_id = %s
            ORDER BY issue_year DESC, id DESC
            """,
            (student_id,)
        )

        certificates = cursor.fetchall()

        # =================================================
        # GET NCC CAMPS
        # =================================================

        cursor.execute(
            """
            SELECT
                id,
                camp_name,
                camp_type,
                camp_level,
                participation_year,
                participation_status,
                achievement,
                description,
                created_at
            FROM camp_records
            WHERE student_id = %s
            ORDER BY participation_year DESC, id DESC
            """,
            (student_id,)
        )

        camps = cursor.fetchall()

        # =================================================
        # GET SPORTS ACHIEVEMENTS
        # =================================================

        cursor.execute(
            """
            SELECT
                id,
                sport_name,
                sport_level,
                achievement,
                position,
                achievement_year,
                participation_type,
                description,
                created_at
            FROM sports_records
            WHERE student_id = %s
            ORDER BY achievement_year DESC, id DESC
            """,
            (student_id,)
        )

        sports = cursor.fetchall()

        # =================================================
        # GET LATEST FITNESS INFORMATION
        # =================================================

        cursor.execute(
            """
            SELECT
                id,
                running_distance,
                pushups,
                situps,
                workout_days,
                workout_duration,
                fitness_goal,
                training_level,
                created_at
            FROM fitness_records
            WHERE student_id = %s
            ORDER BY id DESC
            LIMIT 1
            """,
            (student_id,)
        )

        fitness = cursor.fetchone()

        # =================================================
        # GENERATE PERSONALIZED CAREER GUIDANCE
        # =================================================

        career_guidance = generate_career_recommendations(
            student,
            certificates,
            camps,
            sports,
            fitness
        )

        # =================================================
        # DISPLAY CAREER PAGE
        # =================================================

        return render_template(
            "career.html",

            student=student,

            certificates=certificates,

            camps=camps,

            sports=sports,

            fitness=fitness,

            guidance=career_guidance
        )

    # =====================================================
    # ERROR HANDLING
    # =====================================================

    except Exception as error:

        if connection:

            connection.rollback()

        print(
            "Career Error:",
            error
        )

        # -------------------------------------------------
        # FALLBACK GUIDANCE
        # -------------------------------------------------

        fallback_guidance = {

            "profile_summary": {
                "name": (
                    session.get(
                        "student_name",
                        "Student"
                    )
                ),

                "preferred_wing": "Not available",

                "career_goal": "Not available",

                "education": "Not available",

                "certificates": 0,

                "camps": 0,

                "sports": 0
            },

            "opportunities": [],

            "certificate_guidance": [],

            "camp_benefits": [],

            "sports_opportunities": [],

            "next_steps": []
        }

        return render_template(
            "career.html",

            student=None,

            certificates=[],

            camps=[],

            sports=[],

            fitness=None,

            guidance=fallback_guidance,

            error="Career guidance could not be loaded."
        )

    # =====================================================
    # CLOSE DATABASE
    # =====================================================

    finally:

        if cursor:

            cursor.close()

        if connection:

            connection.close()

# =====================================================
# DIET / NUTRITION GUIDANCE
# =====================================================

@app.route("/diet", methods=["GET", "POST"])
def diet():

    # -------------------------------------------------
    # LOGIN CHECK
    # -------------------------------------------------

    if "student_id" not in session:

        return redirect(
            url_for("login")
        )

    connection = None
    cursor = None

    try:

        connection = get_connection()

        cursor = connection.cursor(
            dictionary=True
        )

        student_id = session["student_id"]

        # =================================================
        # SAVE DIET PREFERENCE
        # =================================================

        if request.method == "POST":

            diet_preference = request.form.get(
                "diet_preference"
            )

            if diet_preference not in [
                "Vegetarian",
                "Non-Vegetarian"
            ]:

                diet_preference = "Vegetarian"

            cursor.execute(
                """
                UPDATE students
                SET diet_preference = %s
                WHERE id = %s
                """,
                (
                    diet_preference,
                    student_id
                )
            )

            connection.commit()

        # =================================================
        # GET STUDENT
        # =================================================

        cursor.execute(
            """
            SELECT
                id,
                name,
                education,
                age,
                preferred_wing,
                career_goal,
                diet_preference
            FROM students
            WHERE id = %s
            """,
            (student_id,)
        )

        student = cursor.fetchone()

        # =================================================
        # GET FITNESS
        # =================================================

        cursor.execute(
            """
            SELECT
                running_distance,
                pushups,
                situps,
                workout_days,
                workout_duration,
                fitness_goal,
                training_level
            FROM fitness_records
            WHERE student_id = %s
            ORDER BY id DESC
            LIMIT 1
            """,
            (student_id,)
        )

        fitness = cursor.fetchone()

        # =================================================
        # GET LATEST INJURY
        # =================================================

        cursor.execute(
            """
            SELECT
                injury_type,
                body_part,
                severity,
                medical_clearance,
                recovery_status,
                pain_level,
                swelling
            FROM injury_records
            WHERE student_id = %s
            ORDER BY id DESC
            LIMIT 1
            """,
            (student_id,)
        )

        injury = cursor.fetchone()

        # =================================================
        # GENERATE DIET GUIDANCE
        # =================================================

        diet_guidance = generate_diet_recommendations(
            student,
            fitness,
            injury
        )

        # =================================================
        # DISPLAY
        # =================================================

        return render_template(
            "diet.html",

            student=student,

            fitness=fitness,

            injury=injury,

            guidance=diet_guidance
        )

    except Exception as error:

        if connection:

            connection.rollback()

        print(
            "Diet Error:",
            error
        )

        return render_template(
            "diet.html",

            student=None,

            fitness=None,

            injury=None,

            guidance=None,

            error=f"Diet guidance could not be loaded: {error}"
        )

    finally:

        if cursor:
            cursor.close()

        if connection:
            connection.close()


@app.route("/schedule", methods=["GET"])
def schedule():
    if "student_id" not in session:
        return redirect(url_for("login"))

    connection = None
    cursor = None

    try:
        connection = get_connection()
        cursor = connection.cursor(dictionary=True)

        student_id = session["student_id"]

        # ---------------------------------------------
        # STUDENT PROFILE
        # ---------------------------------------------

        cursor.execute(
            """
            SELECT
                id,
                name,
                education,
                age,
                preferred_wing,
                career_goal,
                diet_preference
            FROM students
            WHERE id = %s
            """,
            (student_id,)
        )

        student = cursor.fetchone()

        # ---------------------------------------------
        # LATEST FITNESS RECORD
        # ---------------------------------------------

        cursor.execute(
            """
            SELECT
                running_distance,
                pushups,
                situps,
                workout_days,
                workout_duration,
                fitness_goal,
                training_level
            FROM fitness_records
            WHERE student_id = %s
            ORDER BY id DESC
            LIMIT 1
            """,
            (student_id,)
        )

        fitness = cursor.fetchone()

        # ---------------------------------------------
        # LATEST INJURY RECORD
        # ---------------------------------------------

        cursor.execute(
            """
            SELECT
                injury_type,
                body_part,
                severity,
                medical_clearance,
                recovery_status,
                pain_level,
                swelling
            FROM injury_records
            WHERE student_id = %s
            ORDER BY id DESC
            LIMIT 1
            """,
            (student_id,)
        )

        injury = cursor.fetchone()

        # ---------------------------------------------
        # GENERATE PERSONALIZED SCHEDULE
        # ---------------------------------------------

        daily_schedule = generate_daily_schedule(
            student,
            fitness,
            injury
        )

        return render_template(
            "schedule.html",
            student=student,
            fitness=fitness,
            injury=injury,
            guidance=daily_schedule
        )

    except Exception as error:

        if connection:
            connection.rollback()

        print("Schedule Error:", error)

        return render_template(
            "schedule.html",
            student=None,
            fitness=None,
            injury=None,
            guidance=None,
            error=f"Schedule could not be loaded: {error}"
        )

    finally:

        if cursor:
            cursor.close()

        if connection:
            connection.close()

# =====================================================
# MARK DAILY TASK AS COMPLETE
# =====================================================

@app.route("/complete-task/<int:task_id>", methods=["POST"])
def complete_task(task_id):

    # -------------------------------------------------
    # LOGIN CHECK
    # -------------------------------------------------

    if "student_id" not in session:
        return redirect(url_for("login"))

    connection = None
    cursor = None

    try:

        connection = get_connection()

        cursor = connection.cursor(
            dictionary=True
        )

        student_id = session["student_id"]


        # =================================================
        # CHECK THAT TASK BELONGS TO LOGGED-IN STUDENT
        # =================================================

        cursor.execute(
            """
            SELECT
                id,
                status
            FROM daily_tasks
            WHERE id = %s
            AND student_id = %s
            """,
            (
                task_id,
                student_id
            )
        )

        task = cursor.fetchone()


        if not task:

            return redirect(
                url_for("readiness")
            )


        # =================================================
        # MARK TASK AS COMPLETED
        # =================================================

        cursor.execute(
            """
            UPDATE daily_tasks
            SET
                status = 'Completed',
                completed_at = NOW()
            WHERE id = %s
            AND student_id = %s
            """,
            (
                task_id,
                student_id
            )
        )


        connection.commit()


        print(
            "Task completed:",
            task_id,
            "Student:",
            student_id
        )


        return redirect(
            url_for("readiness")
        )


    except Exception as error:

        if connection:
            connection.rollback()

        print(
            "Complete Task Error:",
            error
        )

        return redirect(
            url_for("readiness")
        )


    finally:

        if cursor:
            cursor.close()

        if connection:
            connection.close()


# =====================================================
# AI READINESS DASHBOARD
# =====================================================

@app.route("/readiness")
def readiness():

    # -------------------------------------------------
    # LOGIN CHECK
    # -------------------------------------------------

    if "student_id" not in session:

        return redirect(
            url_for("login")
        )

    connection = None
    cursor = None

    try:

        # =================================================
        # DATABASE CONNECTION
        # =================================================

        connection = get_connection()

        cursor = connection.cursor(
            dictionary=True
        )

        student_id = session["student_id"]


        # =================================================
        # STUDENT PROFILE
        # =================================================

        cursor.execute(
            """
            SELECT
                id,
                name,
                education,
                age,
                preferred_wing,
                career_goal,
                diet_preference
            FROM students
            WHERE id = %s
            """,
            (student_id,)
        )

        student = cursor.fetchone()


        if not student:

            session.clear()

            return redirect(
                url_for("login")
            )


        # =================================================
        # FITNESS
        # =================================================

        cursor.execute(
            """
            SELECT
                running_distance,
                pushups,
                situps,
                workout_days,
                workout_duration,
                fitness_goal,
                training_level
            FROM fitness_records
            WHERE student_id = %s
            ORDER BY id DESC
            LIMIT 1
            """,
            (student_id,)
        )

        fitness = cursor.fetchone()


        # =================================================
        # INJURY
        # =================================================

        cursor.execute(
            """
            SELECT
                injury_type,
                body_part,
                severity,
                medical_clearance,
                recovery_status,
                pain_level,
                swelling
            FROM injury_records
            WHERE student_id = %s
            ORDER BY id DESC
            LIMIT 1
            """,
            (student_id,)
        )

        injury = cursor.fetchone()


        # =================================================
        # SPORTS
        # =================================================

        cursor.execute(
            """
            SELECT
                sport_name,
                sport_level,
                achievement,
                position,
                achievement_year,
                participation_type
            FROM sports_records
            WHERE student_id = %s
            ORDER BY achievement_year DESC, id DESC
            """,
            (student_id,)
        )

        sports = cursor.fetchall()


        # =================================================
        # CERTIFICATES
        # =================================================

        cursor.execute(
            """
            SELECT
                certificate_type,
                certificate_number,
                issue_year,
                grade,
                issuing_authority
            FROM certificate_records
            WHERE student_id = %s
            ORDER BY issue_year DESC, id DESC
            """,
            (student_id,)
        )

        certificates = cursor.fetchall()


        # =================================================
        # CAMPS
        # =================================================

        cursor.execute(
            """
            SELECT
                camp_name,
                camp_type,
                camp_level,
                participation_year,
                participation_status,
                achievement
            FROM camp_records
            WHERE student_id = %s
            ORDER BY participation_year DESC, id DESC
            """,
            (student_id,)
        )

        camps = cursor.fetchall()


        # =================================================
        # PROGRESS
        # =================================================

        cursor.execute(
            """
            SELECT
                progress_date,
                running_distance,
                pushups,
                situps,
                workout_duration,
                workout_days,
                diet_adherence,
                sleep_hours,
                ncc_participation,
                recovery_status
            FROM progress_records
            WHERE student_id = %s
            ORDER BY progress_date DESC, id DESC
            """,
            (student_id,)
        )

        progress = cursor.fetchall()


        # =================================================
        # AI READINESS CALCULATION
        # =================================================

        analysis = generate_readiness_analysis(
            student=student,
            fitness=fitness,
            injury=injury,
            sports=sports,
            certificates=certificates,
            camps=camps,
            progress=progress
        )


        # =================================================
        # SAFE ANALYSIS FALLBACK
        # =================================================

        if not analysis:

            analysis = {}


        analysis.setdefault(
            "overall_score",
            0
        )

        analysis.setdefault(
            "fitness_score",
            0
        )

        analysis.setdefault(
            "sports_score",
            0
        )

        analysis.setdefault(
            "certificate_score",
            0
        )

        analysis.setdefault(
            "camp_score",
            0
        )

        analysis.setdefault(
            "progress_score",
            0
        )

        analysis.setdefault(
            "recovery_score",
            0
        )

        analysis.setdefault(
            "readiness_level",
            "Not Enough Data"
        )

        analysis.setdefault(
            "strengths",
            []
        )

        analysis.setdefault(
            "improvements",
            []
        )

        analysis.setdefault(
            "next_steps",
            []
        )


        # =================================================
        # GENERATE TODAY'S PERSONALIZED TASKS
        # =================================================
        #
        # This creates tasks only if today's tasks
        # do not already exist.
        #

        generate_daily_tasks(
            student_id,
            analysis
        )


        # =================================================
        # GET TODAY'S TASKS
        # =================================================

        today = datetime.now().date()

        # Create a fresh cursor so that the tasks created
        # by generate_daily_tasks() can be retrieved safely.
        cursor.close()

        cursor = connection.cursor(
            dictionary=True
        )

        cursor.execute(
            """
            SELECT
                id,
                task_date,
                task_title,
                category,
                description,
                status,
                completed_at
            FROM daily_tasks
            WHERE student_id = %s
            AND task_date = %s
            ORDER BY id ASC
            """,
            (
                student_id,
                today
            )
        )

        daily_tasks = cursor.fetchall()


        # =================================================
        # READINESS HISTORY
        # =================================================

        cursor.execute(
            """
            SELECT
                readiness_date,
                overall_score,
                fitness_score,
                sports_score,
                certificate_score,
                camp_score,
                progress_score,
                recovery_score
            FROM readiness_history
            WHERE student_id = %s
            ORDER BY readiness_date ASC, id ASC
            """,
            (student_id,)
        )

        readiness_history = cursor.fetchall()


        # =================================================
        # GRAPH DATA
        # =================================================

        chart_dates = []

        chart_scores = []


        for record in readiness_history:

            # ---------------------------------------------
            # DATE
            # ---------------------------------------------

            readiness_date = record.get(
                "readiness_date"
            )


            if readiness_date is not None:

                if hasattr(
                    readiness_date,
                    "strftime"
                ):

                    chart_dates.append(
                        readiness_date.strftime(
                            "%d %b"
                        )
                    )

                else:

                    chart_dates.append(
                        str(readiness_date)
                    )


            # ---------------------------------------------
            # SCORE
            # ---------------------------------------------

            score = record.get(
                "overall_score"
            )


            if score is not None:

                try:

                    chart_scores.append(
                        float(score)
                    )

                except (
                    ValueError,
                    TypeError
                ):

                    chart_scores.append(
                        0
                    )


        # =================================================
        # CURRENT SCORE
        # =================================================
        #
        # Start with the live AI calculation.
        #

        try:

            current_score = float(
                analysis.get(
                    "overall_score",
                    0
                )
            )

        except (
            ValueError,
            TypeError
        ):

            current_score = 0


        # =================================================
        # USE LATEST SAVED HISTORY SCORE
        # =================================================
        #
        # If a readiness history record exists,
        # use its latest score as the official
        # displayed readiness score.
        #

        if readiness_history:

            latest_score = readiness_history[-1].get(
                "overall_score"
            )


            if latest_score is not None:

                try:

                    current_score = float(
                        latest_score
                    )

                except (
                    ValueError,
                    TypeError
                ):

                    pass


        # =================================================
        # KEEP AI ANALYSIS SCORE CONSISTENT
        # =================================================

        analysis["overall_score"] = current_score


        # =================================================
        # KEEP READINESS LEVEL CONSISTENT
        # =================================================

        if current_score >= 80:

            analysis["readiness_level"] = (
                "Highly Prepared"
            )

        elif current_score >= 60:

            analysis["readiness_level"] = (
                "Good Progress"
            )

        elif current_score >= 40:

            analysis["readiness_level"] = (
                "Developing"
            )

        else:

            analysis["readiness_level"] = (
                "Needs Improvement"
            )


        # =================================================
        # PREVIOUS SCORE
        # =================================================

        previous_score = current_score


        if len(readiness_history) >= 2:

            previous_value = readiness_history[-2].get(
                "overall_score"
            )


            if previous_value is not None:

                try:

                    previous_score = float(
                        previous_value
                    )

                except (
                    ValueError,
                    TypeError
                ):

                    previous_score = current_score


        # =================================================
        # SCORE CHANGE
        # =================================================

        change = round(
            current_score - previous_score,
            1
        )


        # =================================================
        # TREND
        # =================================================

        if change > 0:

            trend = "Improving"

        elif change < 0:

            trend = "Declining"

        else:

            trend = "Stable"


        # =================================================
        # HIGHEST / LOWEST
        # =================================================

        if chart_scores:

            highest_score = max(
                chart_scores
            )

            lowest_score = min(
                chart_scores
            )

        else:

            highest_score = current_score

            lowest_score = current_score


        # =================================================
        # DISPLAY READINESS PAGE
        # =================================================

        return render_template(

            "readiness.html",

            student=student,

            fitness=fitness,

            injury=injury,

            sports=sports,

            certificates=certificates,

            camps=camps,

            progress=progress,

            analysis=analysis,

            readiness_history=readiness_history,

            # =================================================
            # DAILY TASKS
            # =================================================

            daily_tasks=daily_tasks,


            # =================================================
            # GRAPH DATA
            # =================================================

            chart_dates=chart_dates,

            chart_scores=chart_scores,


            # =================================================
            # TREND INFORMATION
            # =================================================

            current_score=current_score,

            previous_score=previous_score,

            change=change,

            trend=trend,

            highest_score=highest_score,

            lowest_score=lowest_score
        )


    # =====================================================
    # ERROR HANDLING
    # =====================================================

    except Exception as error:

        if connection:

            connection.rollback()


        print(
            "Readiness Error:",
            error
        )


        return render_template(

            "readiness.html",

            student=None,

            fitness=None,

            injury=None,

            sports=[],

            certificates=[],

            camps=[],

            progress=[],

            analysis=None,

            readiness_history=[],

            daily_tasks=[],

            chart_dates=[],

            chart_scores=[],

            current_score=0,

            previous_score=0,

            change=0,

            trend="Stable",

            highest_score=0,

            lowest_score=0,

            error=(
                "Readiness could not be loaded: "
                f"{error}"
            )
        )


    # =====================================================
    # CLOSE DATABASE
    # =====================================================

    finally:

        if cursor:

            cursor.close()


        if connection:

            connection.close()

# =====================================================
# ADMIN DASHBOARD
# =====================================================

@app.route("/admin")
def admin():

    # -------------------------------------------------
    # LOGIN CHECK
    # -------------------------------------------------

    if "student_id" not in session:
        return redirect(url_for("login"))

    connection = None
    cursor = None

    try:

        connection = get_connection()
        cursor = connection.cursor(dictionary=True)

        # -------------------------------------------------
        # TOTAL REGISTERED CADETS
        # -------------------------------------------------

        cursor.execute(
            """
            SELECT COUNT(*) AS total_cadets
            FROM students
            """
        )

        total_cadets = cursor.fetchone()["total_cadets"]

        # -------------------------------------------------
        # ACTIVE NCC CADETS
        # Students who have selected an NCC wing
        # -------------------------------------------------

        cursor.execute(
            """
            SELECT COUNT(*) AS active_cadets
            FROM students
            WHERE preferred_wing IS NOT NULL
            AND preferred_wing != ''
            """
        )

        active_cadets = cursor.fetchone()["active_cadets"]

        # -------------------------------------------------
        # TOTAL CERTIFICATES
        # -------------------------------------------------

        cursor.execute(
            """
            SELECT COUNT(*) AS total_certificates
            FROM certificate_records
            """
        )

        total_certificates = cursor.fetchone()["total_certificates"]

        # -------------------------------------------------
        # AVERAGE READINESS
        # -------------------------------------------------

        cursor.execute(
            """
            SELECT ROUND(AVG(overall_score), 1) AS average_readiness
            FROM readiness_history
            """
        )

        readiness_result = cursor.fetchone()

        average_readiness = (
            readiness_result["average_readiness"]
            if readiness_result["average_readiness"] is not None
            else 0
        )

        # -------------------------------------------------
        # TOTAL SPORTS RECORDS
        # -------------------------------------------------

        cursor.execute(
            """
            SELECT COUNT(*) AS total_sports
            FROM sports_records
            """
        )

        total_sports = cursor.fetchone()["total_sports"]

        # -------------------------------------------------
        # TOTAL CAMPS
        # -------------------------------------------------

        cursor.execute(
            """
            SELECT COUNT(*) AS total_camps
            FROM camp_records
            """
        )

        total_camps = cursor.fetchone()["total_camps"]

        # -------------------------------------------------
        # FITNESS RECORDS
        # -------------------------------------------------

        cursor.execute(
            """
            SELECT COUNT(*) AS total_fitness
            FROM fitness_records
            """
        )

        total_fitness = cursor.fetchone()["total_fitness"]

        # -------------------------------------------------
        # INJURY / RECOVERY RECORDS
        # -------------------------------------------------

        cursor.execute(
            """
            SELECT COUNT(*) AS total_injuries
            FROM injury_records
            """
        )

        total_injuries = cursor.fetchone()["total_injuries"]

        # -------------------------------------------------
        # RECENT REGISTERED STUDENTS
        # -------------------------------------------------

        cursor.execute(
            """
            SELECT
                id,
                name,
                email,
                preferred_wing,
                career_goal,
                created_at
            FROM students
            ORDER BY id DESC
            LIMIT 10
            """
        )

        recent_students = cursor.fetchall()

        # -------------------------------------------------
        # RENDER ADMIN PAGE
        # -------------------------------------------------

        return render_template(
            "admin.html",

            total_cadets=total_cadets,
            active_cadets=active_cadets,
            total_certificates=total_certificates,
            average_readiness=average_readiness,

            total_sports=total_sports,
            total_camps=total_camps,
            total_fitness=total_fitness,
            total_injuries=total_injuries,

            recent_students=recent_students
        )

    except Exception as error:

        print(
            "Admin Dashboard Error:",
            error
        )

        return render_template(
            "admin.html",

            total_cadets=0,
            active_cadets=0,
            total_certificates=0,
            average_readiness=0,

            total_sports=0,
            total_camps=0,
            total_fitness=0,
            total_injuries=0,

            recent_students=[]
        )

    finally:

        if cursor:
            cursor.close()

        if connection:
            connection.close()

# =====================================================
# AI CHATBOT
# =====================================================

@app.route("/chatbot", methods=["GET", "POST"])
def chatbot():

    # -------------------------------------------------
    # LOGIN CHECK
    # -------------------------------------------------

    if "student_id" not in session:
        return redirect(url_for("login"))

    # -------------------------------------------------
    # POST REQUEST
    # -------------------------------------------------

    if request.method == "POST":

        data = request.get_json()

        message = ""

        if data:
            message = data.get("message", "")

        # -------------------------------------------------
        # GET CURRENT STUDENT
        # -------------------------------------------------

        connection = None
        cursor = None

        student = None

        try:

            connection = get_connection()

            cursor = connection.cursor(
                dictionary=True
            )

            cursor.execute(
                """
                SELECT
                    id,
                    name,
                    education,
                    age,
                    preferred_wing,
                    career_goal,
                    diet_preference
                FROM students
                WHERE id = %s
                """,
                (session["student_id"],)
            )

            student = cursor.fetchone()

            # -------------------------------------------------
            # GET LATEST READINESS SCORE
            # -------------------------------------------------

            if student:

                cursor.execute(
                    """
                    SELECT overall_score
                    FROM readiness_history
                    WHERE student_id = %s
                    ORDER BY readiness_date DESC, id DESC
                    LIMIT 1
                    """,
                    (session["student_id"],)
                )

                readiness = cursor.fetchone()

                if readiness:

                    student["readiness_score"] = (
                        readiness["overall_score"]
                    )

        except Exception as error:

            print(
                "Chatbot Student Data Error:",
                error
            )

        finally:

            if cursor:
                cursor.close()

            if connection:
                connection.close()

        # -------------------------------------------------
        # GENERATE RESPONSE
        # -------------------------------------------------

        response = generate_chatbot_response(
            message,
            student
        )

        return {
            "response": response
        }

    # -------------------------------------------------
    # GET REQUEST
    # -------------------------------------------------

    return render_template(
        "chatbot.html"
    )

# =====================================================
# LOGOUT
# =====================================================

@app.route("/logout")
def logout():

    session.clear()

    return redirect(
        url_for("index")
    )


# =====================================================
# RUN FLASK
# =====================================================

if __name__ == "__main__":

    app.run(
        debug=True
    )