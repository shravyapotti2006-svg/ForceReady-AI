# ==========================================================
# FORCE READY AI - AI ENGINE
# ==========================================================
#
# Modules:
# 1. Fitness Recommendation Engine
# 2. Injury-Aware Fitness Recommendation Engine
# 3. Career Guidance Recommendation Engine
#
# This is a rule-based recommendation system.
# It does NOT diagnose injuries, prescribe medical treatment,
# or guarantee recruitment, eligibility or selection.
# ==========================================================


# ==========================================================
# 1. FITNESS + INJURY RECOMMENDATION ENGINE
# ==========================================================

def generate_fitness_recommendations(fitness, injury):
    """
    Generates fitness recommendations based on:
    - Current fitness information
    - Current injury information

    This system provides general educational guidance.
    It does not diagnose or treat injuries.
    """

    # ======================================================
    # NO INJURY
    # ======================================================

    if not injury:

        return {
            "mode": "normal",

            "title": "Normal Defence Fitness Plan",

            "summary": (
                "No active injury record was found. "
                "Your plan focuses on general endurance, strength, "
                "core fitness, mobility and recovery."
            ),

            "exercises": [
                "Brisk walking or light jogging",
                "Running practice based on your current fitness level",
                "Push-ups for upper-body strength",
                "Bodyweight squats for lower-body strength",
                "Sit-ups or other comfortable core exercises",
                "Plank and basic core stability exercises",
                "Light stretching and mobility"
            ],

            "yoga": [
                "Gentle full-body mobility",
                "Breathing and relaxation exercises",
                "Basic stretching without forcing range of motion",
                "Simple balance and posture exercises"
            ],

            "dos": [
                "Warm up before exercise",
                "Increase training gradually",
                "Maintain proper hydration",
                "Take adequate recovery days",
                "Track your running, strength and workout consistency"
            ],

            "donts": [
                "Do not suddenly increase workout intensity",
                "Do not ignore unusual pain or swelling",
                "Do not train intensely without adequate recovery",
                "Do not compare your progress with another person's fitness level"
            ],

            "diet": [
                "Maintain a balanced diet with adequate protein",
                "Include vegetables and fruits regularly",
                "Choose whole grains and other nutritious carbohydrate sources",
                "Drink enough water throughout the day",
                "Maintain regular meal timing around your training"
            ],

            "warning": (
                "This is general fitness guidance. "
                "Modify or stop an activity if you experience concerning "
                "pain, swelling, dizziness or other unusual symptoms."
            )
        }

    # ======================================================
    # READ INJURY INFORMATION
    # ======================================================

    medical_clearance = (
        injury.get("medical_clearance") or ""
    ).strip().lower()

    injury_type = (
        injury.get("injury_type") or ""
    ).strip().lower()

    body_part = (
        injury.get("body_part") or ""
    ).strip().lower()

    # ======================================================
    # NOT MEDICALLY CLEARED
    # ======================================================

    if medical_clearance == "not cleared":

        return {
            "mode": "injury",

            "title": "Recovery-Support Mode",

            "summary": (
                "Your injury record shows that you are currently "
                "not medically cleared for independent training."
            ),

            "exercises": [],

            "yoga": [
                "Use only activities specifically permitted by your "
                "doctor or physiotherapist.",
                "Gentle breathing or relaxation may be considered "
                "only if comfortable and permitted."
            ],

            "dos": [
                "Follow the instructions provided by your healthcare professional",
                "Keep your injury and recovery information updated",
                "Monitor changes in pain, swelling and recovery status",
                "Return to training only according to appropriate medical guidance"
            ],

            "donts": [
                "Do not create your own rehabilitation program",
                "Do not train through worsening pain or swelling",
                "Do not start running, jumping or heavy strength training independently",
                "Do not treat this system as a replacement for professional care"
            ],

            "diet": [
                "Maintain a balanced and nutritious diet",
                "Include adequate protein from normal food sources",
                "Eat a variety of fruits and vegetables",
                "Stay adequately hydrated",
                "Follow any nutrition advice provided by your healthcare professional"
            ],

            "warning": (
                "Medical clearance is required before independent "
                "injury-related training recommendations are used. "
                "Follow your healthcare professional's instructions."
            )
        }

    # ======================================================
    # RESTRICTED
    # ======================================================

    if medical_clearance == "restricted":

        exercises = [
            "Clinician-approved range-of-motion or mobility work",
            "Gentle muscle activation as permitted",
            "Low-impact conditioning only if approved",
            "Gradual strengthening according to your cleared activity level"
        ]

        yoga = [
            "Gentle breathing exercises",
            "Comfortable mobility movements that do not stress the injured area",
            "Gentle stretching only when permitted",
            "Avoid positions that cause pain or increase symptoms"
        ]

        # Injury-specific guidance
        if "ligament" in injury_type:

            exercises.append(
                "Clinician-approved balance and stability work"
            )

        elif "muscle" in injury_type:

            exercises.append(
                "Gradual strengthening of unaffected areas as permitted"
            )

        elif "sprain" in injury_type or "strain" in injury_type:

            exercises.append(
                "Gradual mobility and strengthening according to clearance"
            )

        elif "fracture" in injury_type:

            exercises = [
                "Follow the prescribed rehabilitation plan",
                "Train only areas and movements that have been medically cleared",
                "Maintain general conditioning only when permitted"
            ]

        return {
            "mode": "injury",

            "title": "Injury-Aware Fitness Plan",

            "summary": (
                f"Your profile contains an active {injury_type or 'injury'} "
                f"affecting the {body_part or 'recorded area'}. "
                "Your fitness recommendations are restricted according "
                "to your current medical clearance."
            ),

            "exercises": exercises,

            "yoga": yoga,

            "dos": [
                "Follow your medical or physiotherapy instructions",
                "Progress gradually within your cleared activity level",
                "Monitor pain and swelling",
                "Allow adequate recovery between sessions",
                "Update your injury status as your recovery progresses"
            ],

            "donts": [
                "Do not train through worsening symptoms",
                "Avoid high-impact or high-load activity unless cleared",
                "Avoid sudden increases in workout intensity",
                "Do not perform movements that your healthcare professional has restricted",
                "Do not treat yoga as a treatment for the injury"
            ],

            "diet": [
                "Maintain a balanced diet during recovery",
                "Include adequate protein from normal food sources",
                "Eat a variety of fruits and vegetables",
                "Stay hydrated",
                "Follow professional nutrition advice if you have been given one"
            ],

            "warning": (
                "Your injury status changes how your fitness plan should "
                "be approached. If pain or swelling increases, reduce or "
                "stop the activity and seek appropriate professional advice."
            )
        }

    # ======================================================
    # MEDICALLY CLEARED
    # ======================================================

    exercises = [
        "Gradual strengthening appropriate to your cleared activity level",
        "Mobility exercises within a comfortable range",
        "Low-impact cardiovascular conditioning",
        "Progressive balance and stability work when appropriate"
    ]

    yoga = [
        "Gentle mobility-focused yoga",
        "Breathing and relaxation exercises",
        "Comfortable stretching",
        "Balance and posture work when appropriate"
    ]

    # Injury-specific guidance
    if "ligament" in injury_type:

        exercises.append(
            "Progressive strength and balance work only as cleared"
        )

    elif "muscle" in injury_type:

        exercises.append(
            "Gradual strengthening and mobility work as cleared"
        )

    elif "sprain" in injury_type or "strain" in injury_type:

        exercises.append(
            "Progressive mobility and strengthening as cleared"
        )

    elif "fracture" in injury_type:

        exercises = [
            "Continue your prescribed rehabilitation plan",
            "Gradual strengthening of medically cleared areas",
            "Low-impact conditioning when permitted",
            "Progress activity according to professional guidance"
        ]

    return {
        "mode": "injury",

        "title": "Injury-Aware Return-to-Training Plan",

        "summary": (
            "Your injury record shows medical clearance. "
            "The system will still keep your recorded injury and "
            "recovery status in consideration."
        ),

        "exercises": exercises,

        "yoga": yoga,

        "dos": [
            "Progress gradually",
            "Follow any restrictions given by your healthcare professional",
            "Monitor your symptoms during and after activity",
            "Include recovery days",
            "Update your injury record when your recovery status changes"
        ],

        "donts": [
            "Do not suddenly return to maximum-intensity training",
            "Do not ignore increasing pain or swelling",
            "Do not perform restricted movements",
            "Do not assume that being medically cleared means every activity is immediately appropriate"
        ],

        "diet": [
            "Maintain a balanced diet",
            "Include adequate protein from normal food sources",
            "Eat vegetables and fruits regularly",
            "Stay hydrated",
            "Maintain regular meals around training and recovery"
        ],

        "warning": (
            "The recommendations are educational and injury-aware. "
            "They do not diagnose or treat an injury. "
            "Follow professional guidance for your individual recovery."
        )
    }


# ==========================================================
# 2. CAREER GUIDANCE AI ENGINE
# ==========================================================

def generate_career_recommendations(
    student,
    certificates,
    camps,
    sports,
    fitness
):
    """
    Generates personalized career guidance using:

    - Student profile
    - NCC certificates
    - NCC camps
    - Sports achievements
    - Fitness information
    - Career goal
    - Preferred NCC wing

    This is a rule-based AI recommendation engine.

    It does not guarantee eligibility, selection,
    employment, concessions or recruitment benefits.
    """

    # ======================================================
    # SAFE DEFAULT VALUES
    # ======================================================

    student = student or {}
    certificates = certificates or []
    camps = camps or []
    sports = sports or []

    # ======================================================
    # RESULT LISTS
    # ======================================================

    recommendations = []
    certificate_guidance = []
    camp_benefits = []
    sports_opportunities = []
    next_steps = []

    # ======================================================
    # STUDENT INFORMATION
    # ======================================================

    name = student.get("name", "Student")

    preferred_wing = (
        student.get("preferred_wing") or ""
    ).strip()

    career_goal = (
        student.get("career_goal") or ""
    ).strip()

    education = (
        student.get("education") or ""
    ).strip()

    # ======================================================
    # COUNTS
    # ======================================================

    certificate_count = len(certificates)
    camp_count = len(camps)
    sports_count = len(sports)

    # ======================================================
    # PROFILE SUMMARY
    # ======================================================

    profile_summary = {
        "name": name,

        "preferred_wing": (
            preferred_wing
            if preferred_wing
            else "Not specified"
        ),

        "career_goal": (
            career_goal
            if career_goal
            else "Not specified"
        ),

        "education": (
            education
            if education
            else "Not specified"
        ),

        "certificates": certificate_count,

        "camps": camp_count,

        "sports": sports_count
    }

    # ======================================================
    # CERTIFICATE ANALYSIS
    # ======================================================

    certificate_types = []

    for certificate in certificates:

        cert_type = (
            certificate.get("certificate_type") or ""
        ).strip().lower()

        if cert_type:
            certificate_types.append(cert_type)

    # Detect Certificate A
    has_a = any(
        "certificate a" in cert
        or cert == "a"
        for cert in certificate_types
    )

    # Detect Certificate B
    has_b = any(
        "certificate b" in cert
        or cert == "b"
        for cert in certificate_types
    )

    # Detect Certificate C
    has_c = any(
        "certificate c" in cert
        or cert == "c"
        for cert in certificate_types
    )

    # ======================================================
    # CERTIFICATE A GUIDANCE
    # ======================================================

    if has_a:

        certificate_guidance.append(
            "Your NCC Certificate A shows foundation-level "
            "NCC participation. Continue developing your NCC "
            "participation, discipline, fitness and leadership profile."
        )

    # ======================================================
    # CERTIFICATE B GUIDANCE
    # ======================================================

    if has_b:

        certificate_guidance.append(
            "Your NCC Certificate B indicates further NCC "
            "training and participation. Explore the requirements "
            "for progressing toward Certificate C if you are "
            "continuing in NCC."
        )

    # ======================================================
    # CERTIFICATE C GUIDANCE
    # ======================================================

    if has_c:

        certificate_guidance.append(
            "Your NCC Certificate C can be relevant when exploring "
            "NCC-related defence and public-service opportunities. "
            "Always check the current official recruitment notification "
            "for exact eligibility and selection rules."
        )

        recommendations.append({
            "title": "Explore NCC-linked defence opportunities",

            "description": (
                "Your Certificate C can make NCC-related defence "
                "pathways worth exploring. Check current official "
                "recruitment notifications and NCC-specific entry routes."
            ),

            "reason": (
                "Certificate C is recorded in your profile."
            )
        })

    # ======================================================
    # NO CERTIFICATE
    # ======================================================

    if certificate_count == 0:

        certificate_guidance.append(
            "No NCC certificate has been added yet. If you hold "
            "an NCC certificate, add it to your profile so Career "
            "Guidance can provide more personalized suggestions."
        )

    # ======================================================
    # CAMP ANALYSIS
    # ======================================================

    national_camp_found = False
    leadership_camp_found = False
    adventure_camp_found = False

    for camp in camps:

        camp_name = str(
            camp.get("camp_name") or ""
        ).lower()

        camp_type = str(
            camp.get("camp_type") or ""
        ).lower()

        achievement = str(
            camp.get("achievement") or ""
        ).lower()

        combined = (
            camp_name
            + " "
            + camp_type
            + " "
            + achievement
        )

        # National / Integration camp
        if (
            "national" in combined
            or "integration" in combined
            or "nic" in combined
        ):

            national_camp_found = True

        # Leadership camp
        if "leadership" in combined:

            leadership_camp_found = True

        # Adventure activities
        if (
            "adventure" in combined
            or "rafting" in combined
            or "trek" in combined
            or "rock climbing" in combined
        ):

            adventure_camp_found = True

    # ======================================================
    # NATIONAL CAMP
    # ======================================================

    if national_camp_found:

        camp_benefits.append(
            "Your national-level camp participation demonstrates "
            "exposure to cadets from different regions and can help "
            "you document teamwork, communication, discipline and "
            "national-integration experience."
        )

        camp_benefits.append(
            "Record the exact camp name, year and achievements in "
            "your profile. This gives you useful evidence of NCC "
            "participation when preparing your academic, career "
            "or interview profile."
        )

        recommendations.append({
            "title": "Use your national camp experience",

            "description": (
                "Highlight your national camp participation and "
                "specific activities when preparing your CV, interview "
                "profile or defence-oriented portfolio."
            ),

            "reason": (
                "National-level camp participation is recorded."
            )
        })

    # ======================================================
    # LEADERSHIP CAMP
    # ======================================================

    if leadership_camp_found:

        camp_benefits.append(
            "Leadership camp experience can be highlighted when "
            "preparing for leadership-oriented interviews and "
            "selection activities."
        )

    # ======================================================
    # ADVENTURE CAMP
    # ======================================================

    if adventure_camp_found:

        camp_benefits.append(
            "Your adventure-related NCC experience can be included "
            "as evidence of participation in challenging team-based "
            "activities."
        )

    # ======================================================
    # NO CAMP
    # ======================================================

    if camp_count == 0:

        camp_benefits.append(
            "No NCC camp has been recorded yet. Add your camp "
            "participation and achievements to receive more "
            "personalized career guidance."
        )

    # ======================================================
    # SPORTS ANALYSIS
    # ======================================================

    for sport in sports:

        sport_name = (
            sport.get("sport_name") or ""
        ).strip()

        if sport_name:

            sports_opportunities.append(
                f"{sport_name} can be highlighted as part of "
                "your sports and extracurricular profile."
            )

    # ======================================================
    # SPORTS EXIST
    # ======================================================

    if sports_count > 0:

        sports_opportunities.append(
            "Some defence, police and public-sector recruitment "
            "processes may recognize sports achievements, but the "
            "accepted sport, competition level, federation and "
            "benefits depend on the specific current recruitment "
            "notification."
        )

        recommendations.append({
            "title": "Build on your sports profile",

            "description": (
                "Keep your sports certificates, competition level, "
                "position and achievement year documented. Check "
                "current recruitment rules for sports-related "
                "eligibility or concessions."
            ),

            "reason": (
                f"{sports_count} sports achievement(s) recorded."
            )
        })

    # ======================================================
    # NO SPORTS
    # ======================================================

    else:

        sports_opportunities.append(
            "No sports achievement has been recorded. If you "
            "participate in sports, add your achievements and "
            "certificates to improve the completeness of your "
            "career profile."
        )

    # ======================================================
    # CAREER GOAL ANALYSIS
    # ======================================================

    goal = career_goal.lower()

    # ======================================================
    # DEFENCE CAREER
    # ======================================================

    if (
        "army" in goal
        or "navy" in goal
        or "air force" in goal
        or "defence" in goal
        or "defense" in goal
    ):

        recommendations.append({
            "title": "Prepare for defence selection requirements",

            "description": (
                "Build your preparation around the requirements "
                "of the specific entry you are targeting, including "
                "academics, written examination where applicable, "
                "physical preparation and interview or SSB preparation "
                "where applicable."
            ),

            "reason": (
                f"Your career goal is related to {career_goal}."
            )
        })

        next_steps.append(
            "Select one or more specific defence entries you want "
            "to explore and verify their current eligibility requirements."
        )

        next_steps.append(
            "Maintain your NCC certificates, camp records and sports "
            "achievements with correct dates and supporting documents."
        )

    # ======================================================
    # POLICE / CAPF
    # ======================================================

    elif (
        "police" in goal
        or "capf" in goal
    ):

        recommendations.append({
            "title": "Explore police and CAPF opportunities",

            "description": (
                "Your profile can be used to explore police and CAPF "
                "recruitment. Check the current recruitment notification "
                "for education, age, physical standards, examination "
                "and NCC or sports-related provisions."
            ),

            "reason": (
                f"Your career goal is related to {career_goal}."
            )
        })

        next_steps.append(
            "Identify the police or CAPF examinations relevant to "
            "your qualification and check their latest official "
            "notifications."
        )

    # ======================================================
    # OTHER CAREER
    # ======================================================

    elif career_goal:

        recommendations.append({
            "title": "Connect your NCC profile with your career goal",

            "description": (
                f"Your selected career goal is {career_goal}. "
                "Use your NCC, camp, sports and fitness records as "
                "supporting experiences while researching the entry "
                "requirements for that field."
            ),

            "reason": (
                "A career goal has been recorded in your profile."
            )
        })

    # ======================================================
    # NO CAREER GOAL
    # ======================================================

    else:

        recommendations.append({
            "title": "Choose a target career pathway",

            "description": (
                "Select a career goal such as Army, Navy, Air Force, "
                "Police, CAPF or another field to receive more "
                "targeted guidance."
            ),

            "reason": (
                "No specific career goal is currently recorded."
            )
        })

    # ======================================================
    # NCC WING ANALYSIS
    # ======================================================

    wing = preferred_wing.lower()

    # ======================================================
    # ARMY WING
    # ======================================================

    if "army" in wing:

        recommendations.append({
            "title": "Explore Army-oriented pathways",

            "description": (
                "Since Army Wing is selected, explore Army officer "
                "and other applicable entry routes and compare their "
                "current eligibility requirements."
            ),

            "reason": (
                "Army Wing is selected in your NCC profile."
            )
        })

    # ======================================================
    # NAVY WING
    # ======================================================

    elif "navy" in wing:

        recommendations.append({
            "title": "Explore Navy-oriented pathways",

            "description": (
                "Since Navy Wing is selected, explore Navy entry "
                "routes that match your educational qualification "
                "and current eligibility."
            ),

            "reason": (
                "Navy Wing is selected in your NCC profile."
            )
        })

    # ======================================================
    # AIR WING
    # ======================================================

    elif "air" in wing:

        recommendations.append({
            "title": "Explore Air Force-oriented pathways",

            "description": (
                "Since Air Wing is selected, explore Air Force "
                "entry routes matching your education and current "
                "eligibility requirements."
            ),

            "reason": (
                "Air Wing is selected in your NCC profile."
            )
        })

    # ======================================================
    # COMBINED PROFILE ANALYSIS
    # ======================================================

    if (
        certificate_count > 0
        and camp_count > 0
        and sports_count > 0
    ):

        recommendations.append({
            "title": "Build a complete defence profile",

            "description": (
                "Your profile contains NCC certificates, camp "
                "participation and sports achievements. Keep these "
                "records updated and prepare a clear summary of "
                "your responsibilities, achievements and skills "
                "for future applications and interviews."
            ),

            "reason": (
                "NCC certificates, camp participation and sports "
                "achievements are all present."
            )
        })

    # ======================================================
    # FITNESS INFORMATION
    # ======================================================

    if fitness:

        running = fitness.get(
            "running_distance",
            0
        )

        pushups = fitness.get(
            "pushups",
            0
        )

        situps = fitness.get(
            "situps",
            0
        )

        next_steps.append(
            "Continue recording your fitness progress so the "
            "system can track changes over time."
        )

        if running:

            next_steps.append(
                f"Your recorded running distance is {running} km. "
                "Continue progressive and appropriate physical preparation."
            )

        if pushups:

            next_steps.append(
                f"Your recorded push-up count is {pushups}. "
                "Track your progress regularly rather than relying "
                "on a single result."
            )

        if situps:

            next_steps.append(
                f"Your recorded sit-up count is {situps}. "
                "Continue monitoring your fitness development."
            )

    else:

        next_steps.append(
            "Add your fitness information so your career preparation "
            "profile can include fitness progress."
        )

    # ======================================================
    # GENERAL NEXT STEPS
    # ======================================================

    next_steps.extend([
        "Keep your NCC certificates and achievement records updated.",

        "Maintain evidence of camp participation and sports achievements.",

        "Check official recruitment notifications before relying on "
        "any eligibility, concession or benefit.",

        "Use the Career Guidance module as a planning aid rather than "
        "as a substitute for official eligibility rules."
    ])

    # ======================================================
    # REMOVE DUPLICATE NEXT STEPS
    # ======================================================

    next_steps = list(
        dict.fromkeys(next_steps)
    )

    # ======================================================
    # REMOVE DUPLICATE RECOMMENDATIONS
    # ======================================================

    unique_recommendations = []

    recommendation_titles = set()

    for recommendation in recommendations:

        title = recommendation.get("title")

        if title not in recommendation_titles:

            recommendation_titles.add(title)

            unique_recommendations.append(
                recommendation
            )

    # ======================================================
    # FINAL RESULT
    # ======================================================

    return {
        "profile_summary": profile_summary,

        "opportunities": unique_recommendations,

        "certificate_guidance": certificate_guidance,

        "camp_benefits": camp_benefits,

        "sports_opportunities": sports_opportunities,

        "next_steps": next_steps
    }

# ==========================================================
# DIET / NUTRITION GUIDANCE
# ==========================================================

def generate_diet_recommendations(
    student,
    fitness=None,
    injury=None
):
    """
    Generates general nutrition guidance based on:

    1. Vegetarian / Non-Vegetarian preference
    2. Fitness information
    3. Career goal
    4. Injury / recovery status

    This is general educational nutrition guidance.
    It does not diagnose medical conditions or prescribe
    a therapeutic diet.
    """

    # ======================================================
    # 1. GET DIET PREFERENCE
    # ======================================================

    diet_preference = (
        student.get("diet_preference")
        or "Vegetarian"
    ).strip().lower()

    if diet_preference in [
        "non-veg",
        "non veg",
        "non vegetarian",
        "non-vegetarian",
        "nonveg"
    ]:

        diet_type = "Non-Vegetarian"

    else:

        diet_type = "Vegetarian"


    # ======================================================
    # 2. GET CAREER GOAL
    # ======================================================

    career_goal = (
        student.get("career_goal")
        or ""
    ).strip()


    # ======================================================
    # 3. GET FITNESS INFORMATION
    # ======================================================

    fitness_goal = ""
    training_level = ""

    if fitness:

        fitness_goal = (
            fitness.get("fitness_goal")
            or ""
        ).strip()

        training_level = (
            fitness.get("training_level")
            or ""
        ).strip()


    # ======================================================
    # 4. GET INJURY / RECOVERY INFORMATION
    # ======================================================

    recovery_status = ""
    medical_clearance = ""

    if injury:

        recovery_status = (
            injury.get("recovery_status")
            or ""
        ).strip().lower()

        medical_clearance = (
            injury.get("medical_clearance")
            or ""
        ).strip().lower()


    # ======================================================
    # 5. COMMON NUTRITION GUIDANCE
    # ======================================================

    common_guidance = [

        "Include a variety of vegetables and fruits throughout the day.",

        (
            "Choose nutritious carbohydrate sources such as "
            "whole grains, rice, roti, oats, potatoes and other "
            "minimally processed carbohydrate foods according "
            "to your needs."
        ),

        "Include regular protein sources across meals.",

        (
            "Drink water regularly and pay attention to hydration "
            "around physical activity."
        ),

        "Maintain regular meals instead of frequently skipping meals.",

        (
            "Prefer a balanced diet rather than relying heavily "
            "on highly processed foods and sugary drinks."
        )
    ]


    # ======================================================
    # 6. VEGETARIAN PROTEIN SOURCES
    # ======================================================

    vegetarian_proteins = [

        "Dal and other pulses",

        "Rajma, chickpeas and other beans",

        "Soy products such as tofu or soybeans",

        "Milk, curd and other dairy foods if tolerated",

        "Paneer in appropriate portions",

        "Nuts and seeds such as peanuts, almonds and sesame",

        "Sprouts and other legume-based foods"
    ]


    # ======================================================
    # 7. NON-VEGETARIAN PROTEIN SOURCES
    # ======================================================

    non_vegetarian_proteins = [

        "Eggs",

        "Chicken or other lean poultry",

        "Fish",

        "Lean meat in appropriate portions",

        "Milk, curd and other dairy foods if tolerated",

        "Dal, beans and other plant-based protein sources",

        "Nuts and seeds"
    ]


    # ======================================================
    # 8. BREAKFAST
    # ======================================================

    if diet_type == "Vegetarian":

        breakfast = [

            "Oats with milk or curd and fruit",

            "Vegetable poha with curd",

            "Idli or dosa with sambar",

            "Vegetable upma with a protein-rich side",

            "Paneer or vegetable sandwich with fruit",

            "Paratha with curd and vegetables in a balanced portion"
        ]

    else:

        breakfast = [

            "Eggs with whole-grain toast and fruit",

            "Omelette with vegetables and roti",

            "Oats with milk or curd and fruit",

            "Egg sandwich with vegetables",

            "Idli or dosa with sambar and eggs",

            "Vegetable poha with eggs as an additional protein source"
        ]


    # ======================================================
    # 9. LUNCH
    # ======================================================

    if diet_type == "Vegetarian":

        lunch = [

            "Roti or rice with dal, vegetables and curd",

            "Rajma or chickpeas with rice and vegetables",

            "Roti with paneer, dal and vegetables",

            "Vegetable khichdi with curd and salad",

            "Tofu or soy-based meal with rice or roti and vegetables"
        ]

    else:

        lunch = [

            "Roti or rice with chicken and vegetables",

            "Rice with fish, dal and vegetables",

            "Roti with lean meat, vegetables and curd",

            "Chicken or fish with rice and a vegetable side",

            "Egg-based meal with roti or rice, dal and vegetables"
        ]


    # ======================================================
    # 10. HEALTHY SNACK OPTIONS
    # ======================================================

    snacks = [

        "Fruit",

        "Roasted chana",

        "Peanuts or mixed nuts",

        "Curd or yogurt",

        "Sprouts",

        "Milk",

        "Homemade snack with a protein source"
    ]


    # ======================================================
    # 11. DINNER
    # ======================================================

    if diet_type == "Vegetarian":

        dinner = [

            "Roti with dal and vegetables",

            "Rice with dal, vegetables and curd",

            "Paneer or tofu with vegetables and roti",

            "Vegetable khichdi with curd",

            (
                "A light balanced meal containing a "
                "carbohydrate, protein source and vegetables"
            )
        ]

    else:

        dinner = [

            "Roti with chicken and vegetables",

            "Fish with rice and vegetables",

            "Egg curry with roti and vegetables",

            "Chicken with rice and a vegetable side",

            (
                "A light balanced meal containing a "
                "carbohydrate, protein source and vegetables"
            )
        ]


    # ======================================================
    # 12. NUTRITION AROUND TRAINING
    # ======================================================

    training_guidance = [

        (
            "Have a balanced meal or snack around training "
            "depending on the timing and intensity of your workout."
        ),

        "Include a protein source regularly throughout the day.",

        (
            "Replace fluids lost during exercise, especially "
            "during longer or more intense sessions."
        ),

        (
            "Avoid starting demanding training sessions after "
            "unnecessarily long periods without food or fluids."
        ),

        (
            "Use your energy levels and training response to "
            "understand whether your meal routine is working well."
        )
    ]


    # ======================================================
    # 13. RECOVERY NUTRITION
    # ======================================================

    recovery_guidance = [

        (
            "Maintain adequate overall food and fluid intake "
            "during recovery."
        ),

        "Include regular protein-containing foods.",

        "Eat a variety of fruits and vegetables.",

        "Maintain regular sleep and recovery habits.",

        (
            "Follow any nutrition instructions provided by your "
            "healthcare professional if you are recovering from "
            "an injury."
        )
    ]


    # ======================================================
    # 14. MEDICAL CLEARANCE / INJURY MESSAGE
    # ======================================================

    if medical_clearance == "not cleared":

        recovery_warning = (
            "Your injury record indicates that you are not "
            "medically cleared. The nutrition guidance shown "
            "here is general only. Follow your healthcare "
            "professional's individual nutrition and recovery "
            "instructions."
        )

    elif recovery_status:

        recovery_warning = (
            "Your recorded recovery status is considered when "
            "displaying general nutrition guidance. Nutrition "
            "cannot replace professional injury management."
        )

    else:

        recovery_warning = (
            "If you have a medical condition, food allergy or "
            "specific nutritional requirement, consult an "
            "appropriate healthcare professional or registered "
            "dietitian for individualized advice."
        )


    # ======================================================
    # 15. CAREER / DEFENCE PREPARATION
    # ======================================================

    if career_goal:

        career_message = (
            f"Your recorded career goal is {career_goal}. "
            "Maintain a sustainable eating routine that supports "
            "your study, training, recovery and daily activities."
        )

    else:

        career_message = (
            "For defence preparation, focus on consistent "
            "nutrition, adequate hydration, regular meals, "
            "recovery and a balanced intake that supports "
            "your training routine."
        )


    # ======================================================
    # 16. FITNESS-SPECIFIC MESSAGE
    # ======================================================

    if fitness_goal:

        fitness_message = (
            f"Your recorded fitness goal is {fitness_goal}. "
            "Choose meals that provide a balanced combination "
            "of carbohydrates, protein, vegetables, fruits "
            "and fluids to support your training routine."
        )

    elif training_level:

        fitness_message = (
            f"Your recorded training level is {training_level}. "
            "Adjust meal quantity and timing according to your "
            "activity level, energy needs and overall routine."
        )

    else:

        fitness_message = (
            "As your fitness information develops, your nutrition "
            "guidance can be considered alongside your training "
            "routine."
        )


    # ======================================================
    # 17. RETURN PERSONALIZED GUIDANCE
    # ======================================================

    return {

        "diet_type": diet_type,

        "title": (
            f"{diet_type} Nutrition Guidance"
        ),

        "summary": (
            f"Your current nutrition preference is "
            f"{diet_type}. The guidance provides general "
            "food ideas to support an active lifestyle, "
            "fitness preparation and recovery."
        ),

        "common_guidance": common_guidance,

        "protein_sources": (
            vegetarian_proteins
            if diet_type == "Vegetarian"
            else non_vegetarian_proteins
        ),

        "breakfast": breakfast,

        "lunch": lunch,

        "snacks": snacks,

        "dinner": dinner,

        "training": training_guidance,

        "recovery": recovery_guidance,

        "career_message": career_message,

        "fitness_message": fitness_message,

        "warning": recovery_warning
    }

def generate_daily_schedule(
    student,
    fitness=None,
    injury=None
):
    """
    Generates a general personalized daily schedule
    based on student profile, fitness and recovery status.

    This is an educational planning tool and not medical advice.
    """

    career_goal = (
        student.get("career_goal")
        or "Defence Preparation"
    ).strip()

    diet_preference = (
        student.get("diet_preference")
        or "Vegetarian"
    ).strip()

    training_level = ""
    fitness_goal = ""

    if fitness:
        training_level = (
            fitness.get("training_level")
            or "Beginner"
        ).strip()

        fitness_goal = (
            fitness.get("fitness_goal")
            or "General Fitness"
        ).strip()

    recovery_status = ""
    medical_clearance = ""

    if injury:
        recovery_status = (
            injury.get("recovery_status")
            or ""
        ).strip().lower()

        medical_clearance = (
            injury.get("medical_clearance")
            or ""
        ).strip().lower()

    # -------------------------------------------------
    # DEFAULT SCHEDULE
    # -------------------------------------------------

    schedule = [
        {
            "time": "6:00 AM",
            "activity": "Wake Up & Hydration",
            "details": (
                "Start the day with water and prepare "
                "for the day's activities."
            )
        },
        {
            "time": "6:30 AM",
            "activity": "Fitness / Training",
            "details": (
                "Perform your planned fitness activities "
                "according to your current training level."
            )
        },
        {
            "time": "7:30 AM",
            "activity": "Cool Down & Recovery",
            "details": (
                "Allow time for cooldown, hydration and "
                "recovery after physical activity."
            )
        },
        {
            "time": "8:00 AM",
            "activity": "Breakfast",
            "details": (
                f"Have a balanced {diet_preference.lower()} "
                "breakfast containing carbohydrates, "
                "protein and other nutritious foods."
            )
        },
        {
            "time": "9:00 AM",
            "activity": "Study / College",
            "details": (
                "Attend classes and complete academic work."
            )
        },
        {
            "time": "1:00 PM",
            "activity": "Lunch",
            "details": (
                "Have a balanced lunch with a protein source, "
                "vegetables and an appropriate carbohydrate source."
            )
        },
        {
            "time": "2:00 PM",
            "activity": "Study / Academic Work",
            "details": (
                "Focus on university subjects, assignments "
                "and technical preparation."
            )
        },
        {
            "time": "5:00 PM",
            "activity": "NCC / Skill Development",
            "details": (
                "Use this time for NCC activities, defence "
                "knowledge, communication skills or SSB preparation."
            )
        },
        {
            "time": "6:30 PM",
            "activity": "Light Activity / Recovery",
            "details": (
                "Perform appropriate light activity or "
                "recovery work according to your condition."
            )
        },
        {
            "time": "8:00 PM",
            "activity": "Dinner",
            "details": (
                f"Have a balanced {diet_preference.lower()} "
                "dinner and maintain adequate hydration."
            )
        },
        {
            "time": "9:00 PM",
            "activity": "Daily Progress Update",
            "details": (
                "Record workout, diet adherence, recovery "
                "status and NCC participation."
            )
        },
        {
            "time": "10:30 PM",
            "activity": "Sleep",
            "details": (
                "Maintain a consistent sleep routine to "
                "support recovery and daily performance."
            )
        }
    ]

    # -------------------------------------------------
    # INJURY-AWARE MODIFICATION
    # -------------------------------------------------

    warning = (
        "This schedule is general educational guidance. "
        "Adjust physical activity according to your "
        "healthcare professional's advice."
    )

    if medical_clearance == "not cleared":
        schedule[1]["activity"] = "Recovery / Rest"
        schedule[1]["details"] = (
            "Do not perform demanding physical training "
            "unless cleared by your healthcare professional. "
            "Follow your prescribed recovery plan."
        )

        schedule[7]["activity"] = "NCC Knowledge / SSB Preparation"
        schedule[7]["details"] = (
            "Use this time for defence awareness, SSB "
            "preparation, communication skills or study "
            "instead of demanding physical training."
        )

        warning = (
            "Your recorded injury status indicates that you "
            "are not medically cleared. Avoid demanding "
            "physical training and follow your healthcare "
            "professional's instructions."
        )

    elif recovery_status:
        schedule[1]["activity"] = "Fitness / Recovery-Aware Training"
        schedule[1]["details"] = (
            "Follow only activities appropriate for your "
            "recorded recovery status and medical clearance."
        )

        warning = (
            "Your schedule considers your recorded recovery "
            "status. Physical activity should remain within "
            "your medically appropriate limits."
        )

    return {
        "title": "Your Personalized Daily Schedule",
        "career_goal": career_goal,
        "fitness_goal": fitness_goal,
        "training_level": training_level,
        "diet_preference": diet_preference,
        "schedule": schedule,
        "warning": warning
    }

def generate_readiness_analysis(
    student,
    fitness=None,
    injury=None,
    sports=None,
    certificates=None,
    camps=None,
    progress=None
):
        
    """
    Calculates an overall defence-readiness analysis
    using the student's available records.

    This is an educational project score and should not
    be treated as an official defence recruitment score.
    """

    # ---------------------------------------------
    # DEFAULT VALUES
    # ---------------------------------------------

    fitness_score = 0
    sports_score = 0
    certificate_score = 0
    camp_score = 0
    progress_score = 0
    recovery_score = 0

    # ---------------------------------------------
    # FITNESS SCORE
    # ---------------------------------------------

    if fitness:

        running = float(
            fitness.get("running_distance") or 0
        )

        pushups = int(
            fitness.get("pushups") or 0
        )

        situps = int(
            fitness.get("situps") or 0
        )

        workout_days = int(
            fitness.get("workout_days") or 0
        )

        fitness_score = (
            min(running / 5 * 30, 30)
            + min(pushups / 40 * 25, 25)
            + min(situps / 40 * 20, 20)
            + min(workout_days / 5 * 25, 25)
        )

    fitness_score = round(
        min(fitness_score, 100)
    )

    # ---------------------------------------------
    # SPORTS SCORE
    # ---------------------------------------------

    if sports:
        sports_score = min(
            len(sports) * 20,
            100
        )

    # ---------------------------------------------
    # CERTIFICATE SCORE
    # ---------------------------------------------

    if certificates:

        certificate_types = []

        for certificate in certificates:

            certificate_type = (
                certificate.get("certificate_type")
                or ""
            ).upper()

            if certificate_type not in certificate_types:
                certificate_types.append(
                    certificate_type
                )

        if "A" in certificate_types:
            certificate_score += 20

        if "B" in certificate_types:
            certificate_score += 30

        if "C" in certificate_types:
            certificate_score += 50

        certificate_score = min(
            certificate_score,
            100
        )

    # ---------------------------------------------
    # CAMP SCORE
    # ---------------------------------------------

    if camps:
        camp_score = min(
            len(camps) * 20,
            100
        )

    # ---------------------------------------------
    # PROGRESS SCORE
    # ---------------------------------------------

    if progress:

        diet_values = []
        ncc_values = []
        sleep_values = []

        for record in progress:

            if record.get("diet_adherence") is not None:
                diet_values.append(
                    float(record["diet_adherence"])
                )

            if record.get("ncc_participation") is not None:
                ncc_values.append(
                    float(record["ncc_participation"])
                )

            if record.get("sleep_hours") is not None:
                sleep_values.append(
                    float(record["sleep_hours"])
                )

        diet_average = (
            sum(diet_values) / len(diet_values)
            if diet_values else 0
        )

        ncc_average = (
            sum(ncc_values) / len(ncc_values)
            if ncc_values else 0
        )

        sleep_average = (
            sum(sleep_values) / len(sleep_values)
            if sleep_values else 0
        )

        sleep_score = min(
            sleep_average / 8 * 100,
            100
        )

        progress_score = (
            diet_average * 0.35
            + ncc_average * 0.35
            + sleep_score * 0.30
        )

    progress_score = round(
        min(progress_score, 100)
    )

    # ---------------------------------------------
    # RECOVERY SCORE
    # ---------------------------------------------

    if not injury:

        recovery_score = 100

    else:

        medical_clearance = (
            injury.get("medical_clearance")
            or ""
        ).strip().lower()

        recovery_status = (
            injury.get("recovery_status")
            or ""
        ).strip().lower()

        pain_level = int(
            injury.get("pain_level") or 0
        )

        if medical_clearance == "not cleared":

            recovery_score = 30

        elif recovery_status in [
            "recovering",
            "under treatment",
            "restricted"
        ]:

            recovery_score = 60

        elif recovery_status in [
            "recovered",
            "fully recovered",
            "cleared"
        ]:

            recovery_score = 100

        else:

            recovery_score = max(
                50,
                100 - (pain_level * 10)
            )

    # ---------------------------------------------
    # OVERALL SCORE
    # ---------------------------------------------

    overall_score = round(
        (
            fitness_score * 0.30
            + sports_score * 0.10
            + certificate_score * 0.15
            + camp_score * 0.10
            + progress_score * 0.20
            + recovery_score * 0.15
        )
    )

    overall_score = max(
        0,
        min(overall_score, 100)
    )

    # ---------------------------------------------
    # READINESS LEVEL
    # ---------------------------------------------

    if overall_score >= 80:

        readiness_level = "Highly Prepared"

    elif overall_score >= 60:

        readiness_level = "Good Progress"

    elif overall_score >= 40:

        readiness_level = "Developing"

    else:

        readiness_level = "Needs Improvement"

    # ---------------------------------------------
    # STRENGTHS
    # ---------------------------------------------

    strengths = []

    if fitness_score >= 70:
        strengths.append(
            "Your fitness activity shows consistent preparation."
        )

    if sports_score >= 40:
        strengths.append(
            "Your sports participation adds to your overall profile."
        )

    if certificate_score >= 50:
        strengths.append(
            "Your NCC certificate record shows useful NCC progression."
        )

    if camp_score >= 40:
        strengths.append(
            "Your camp participation demonstrates NCC involvement."
        )

    if progress_score >= 60:
        strengths.append(
            "Your recorded progress shows consistency in preparation."
        )

    if recovery_score >= 80:
        strengths.append(
            "Your recorded recovery status is currently favorable."
        )

    if not strengths:
        strengths.append(
            "Continue building consistent fitness, NCC participation "
            "and progress records."
        )

    # ---------------------------------------------
    # AREAS TO IMPROVE
    # ---------------------------------------------

    improvements = []

    if fitness_score < 60:
        improvements.append(
            "Improve consistency in your fitness preparation."
        )

    if sports_score < 40:
        improvements.append(
            "Consider maintaining regular sports participation."
        )

    if certificate_score < 50:
        improvements.append(
            "Continue progressing through relevant NCC certification."
        )

    if camp_score < 40:
        improvements.append(
            "Increase meaningful NCC camp participation where available."
        )

    if progress_score < 60:
        improvements.append(
            "Maintain regular progress updates for diet, NCC participation "
            "and daily preparation."
        )

    if recovery_score < 70:
        improvements.append(
            "Give appropriate attention to recovery and follow "
            "professional medical guidance where applicable."
        )

    # ---------------------------------------------
    # NEXT STEPS
    # ---------------------------------------------

    next_steps = [
        "Maintain a consistent daily preparation routine.",
        "Continue recording fitness and progress activities.",
        "Keep your NCC certificates, camps and achievements updated.",
        "Maintain balanced nutrition and adequate hydration.",
        "Review your career goal and prepare relevant skills."
    ]

    if recovery_score < 70:

        next_steps.insert(
            0,
            "Prioritize appropriate recovery before increasing demanding physical training."
        )

    # ---------------------------------------------
    # RETURN
    # ---------------------------------------------

    return {
        "overall_score": overall_score,
        "readiness_level": readiness_level,

        "fitness_score": fitness_score,
        "sports_score": sports_score,
        "certificate_score": certificate_score,
        "camp_score": camp_score,
        "progress_score": progress_score,
        "recovery_score": recovery_score,

        "strengths": strengths,
        "improvements": improvements,
        "next_steps": next_steps
    }

# =====================================================
# FORCE READY AI CHATBOT
# =====================================================

def generate_chatbot_response(message, student=None):

    message = (message or "").strip().lower()

    # -------------------------------------------------
    # EMPTY MESSAGE
    # -------------------------------------------------

    if not message:
        return "Please enter a question so I can help you."


    # -------------------------------------------------
    # GREETING
    # -------------------------------------------------

    if any(word in message for word in [
        "hello",
        "hi",
        "hey",
        "hii",
        "good morning",
        "good afternoon",
        "good evening"
    ]):

        return (
            "👋 Hello! I'm ForceReady AI. "
            "I can help you with NCC, defence careers, "
            "fitness preparation, nutrition, certificates, "
            "camps, daily schedules and readiness."
        )


    # -------------------------------------------------
    # NCC C CERTIFICATE
    # -------------------------------------------------

    if (
        "c certificate" in message
        or "c-certificate" in message
        or "ncc certificate" in message
    ):

        return (
            "🎖️ The NCC C Certificate is the highest-level "
            "NCC certificate. It is obtained after meeting "
            "the required NCC training and examination "
            "requirements. It can be useful for students "
            "planning defence-oriented careers."
        )


    # -------------------------------------------------
    # NCC A / B CERTIFICATE
    # -------------------------------------------------

    if (
        "a certificate" in message
        or "b certificate" in message
        or "certificate" in message
    ):

        return (
            "📜 NCC provides A, B and C certificate levels. "
            "Your ForceReady profile can store certificate "
            "type, certificate number, year, grade and "
            "issuing authority."
        )


    # -------------------------------------------------
    # NCC CAMPS
    # -------------------------------------------------

    if (
        "camp" in message
        or "ncc camp" in message
        or "camps" in message
    ):

        return (
            "⛺ NCC camps provide cadets with opportunities "
            "for training, discipline, teamwork and "
            "participation in organized NCC activities. "
            "You can record your camp participation in "
            "the ForceReady Camps module."
        )


    # -------------------------------------------------
    # NCC WINGS
    # -------------------------------------------------

    if (
        "ncc wing" in message
        or "army wing" in message
        or "navy wing" in message
        or "air wing" in message
    ):

        return (
            "🪖 NCC has Army, Naval and Air wings. "
            "Each wing provides cadets with training "
            "related to its respective field."
        )


    # -------------------------------------------------
    # DEFENCE CAREERS
    # -------------------------------------------------

    if (
        "career" in message
        or "defence career" in message
        or "defense career" in message
        or "army job" in message
        or "navy job" in message
        or "air force" in message
        or "police" in message
        or "capf" in message
    ):

        return (
            "🎯 Defence-related career paths can include "
            "the Army, Navy, Air Force, CAPF and other "
            "uniformed services. ForceReady can use your "
            "career goal, NCC profile, fitness information "
            "and achievements to provide general career "
            "guidance."
        )


    # -------------------------------------------------
    # FITNESS
    # -------------------------------------------------

    if (
        "fitness" in message
        or "workout" in message
        or "exercise" in message
        or "pushup" in message
        or "push-ups" in message
        or "running" in message
        or "run" in message
    ):

        return (
            "💪 A balanced preparation routine can include "
            "running or aerobic activity, strength exercises, "
            "mobility and adequate recovery. Increase training "
            "gradually and keep your recorded fitness progress "
            "updated in ForceReady."
        )


    # -------------------------------------------------
    # NUTRITION
    # -------------------------------------------------

    if (
        "diet" in message
        or "nutrition" in message
        or "food" in message
        or "protein" in message
        or "hydration" in message
    ):

        return (
            "🥗 Good preparation includes balanced nutrition, "
            "adequate fluids and regular meals. Your "
            "ForceReady Diet module can provide guidance "
            "according to your selected vegetarian or "
            "non-vegetarian preference."
        )


    # -------------------------------------------------
    # READINESS SCORE
    # -------------------------------------------------

    if (
        "readiness" in message
        or "readiness score" in message
        or "score" in message
    ):

        if student and student.get("readiness_score") is not None:

            return (
                "📊 Your current recorded ForceReady readiness "
                "score is "
                + str(student["readiness_score"])
                + "%. This is an educational project score "
                  "based on your recorded preparation data "
                  "and is not an official recruitment score."
            )

        return (
            "📊 Your ForceReady readiness score combines "
            "recorded areas such as fitness, sports, "
            "certificates, camps, progress and recovery. "
            "It is an educational project indicator and "
            "not an official defence recruitment score."
        )


    # -------------------------------------------------
    # DAILY SCHEDULE
    # -------------------------------------------------

    if (
        "schedule" in message
        or "daily routine" in message
        or "daily plan" in message
        or "routine" in message
    ):

        return (
            "🗓️ A useful daily preparation schedule can "
            "balance studies, NCC activities, fitness, "
            "nutrition, recovery and sleep. Your ForceReady "
            "Daily Schedule module is designed to organize "
            "these activities."
        )


    # -------------------------------------------------
    # SSB
    # -------------------------------------------------

    if (
        "ssb" in message
        or "interview" in message
        or "selection board" in message
    ):

        return (
            "📚 SSB preparation can involve communication, "
            "reasoning, group activities, awareness, "
            "leadership and interview preparation. "
            "Build these skills consistently rather than "
            "focusing only on one type of test."
        )


    # -------------------------------------------------
    # INJURY / RECOVERY
    # -------------------------------------------------

    if (
        "injury" in message
        or "injured" in message
        or "recovery" in message
        or "pain" in message
        or "ligament" in message
    ):

        return (
            "🩹 For injury or recovery concerns, ForceReady "
            "can help record your status and provide general "
            "safety-oriented guidance. Do not use the chatbot "
            "to diagnose an injury or determine medical "
            "fitness. Follow advice and clearance from your "
            "qualified healthcare professional before "
            "returning to demanding physical activity."
        )


    # -------------------------------------------------
    # SPORTS
    # -------------------------------------------------

    if (
        "sport" in message
        or "sports" in message
        or "achievement" in message
    ):

        return (
            "🏆 Sports participation can be recorded in your "
            "ForceReady profile along with the sport, level, "
            "achievement and year. Keeping these records "
            "updated helps maintain your complete cadet profile."
        )


    # -------------------------------------------------
    # HELP
    # -------------------------------------------------

    if (
        "help" in message
        or "what can you do" in message
        or "what do you do" in message
    ):

        return (
            "🤖 I can help with:\n\n"
            "• NCC wings and certificates\n"
            "• NCC camps\n"
            "• Defence career guidance\n"
            "• Fitness preparation\n"
            "• Nutrition\n"
            "• Daily schedules\n"
            "• SSB preparation\n"
            "• Sports records\n"
            "• Recovery awareness\n"
            "• Readiness score explanation"
        )


    # -------------------------------------------------
    # DEFAULT RESPONSE
    # -------------------------------------------------

    return (
        "🤖 I can help with NCC, defence careers, fitness, "
        "nutrition, certificates, camps, SSB preparation, "
        "daily schedules and readiness. Try asking me a "
        "specific question such as 'How can I improve my "
        "fitness?'"
    )