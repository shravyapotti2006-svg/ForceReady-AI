console.log("ForceReady AI loaded successfully");

document.addEventListener("DOMContentLoaded", function () {

    const cards = document.querySelectorAll(
        ".feature-card, .info-card, .stat-card"
    );

    cards.forEach(function (card) {

        card.addEventListener("mouseenter", function () {
            card.style.cursor = "pointer";
        });

    });

});